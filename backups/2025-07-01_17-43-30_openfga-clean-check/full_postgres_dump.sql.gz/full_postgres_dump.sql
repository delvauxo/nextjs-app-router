--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE delvauxo;
ALTER ROLE delvauxo WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:uG/3jkQfYS9PieL/5WVoOw==$UiyAaRoKNXDDknD66UI5eZIfB8dDhnDJh5wbQLQOao4=:e42rJvmI4L5KAI1CuwhEeB+tkOuWqmUl0LKj+BnmqHk=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "keycloak" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: keycloak; Type: DATABASE; Schema: -; Owner: delvauxo
--

CREATE DATABASE keycloak WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE keycloak OWNER TO delvauxo;

\connect keycloak

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64),
    details_json text
);


ALTER TABLE public.admin_event_entity OWNER TO delvauxo;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO delvauxo;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO delvauxo;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO delvauxo;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.authenticator_config (
    id character varying(36) NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO delvauxo;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO delvauxo;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO delvauxo;

--
-- Name: client; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO delvauxo;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO delvauxo;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO delvauxo;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO delvauxo;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) NOT NULL,
    value integer,
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO delvauxo;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_scope (
    id character varying(36) NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO delvauxo;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) NOT NULL,
    value character varying(2048),
    name character varying(255) NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO delvauxo;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO delvauxo;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO delvauxo;

--
-- Name: component; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO delvauxo;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO delvauxo;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO delvauxo;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer,
    version integer DEFAULT 0
);


ALTER TABLE public.credential OWNER TO delvauxo;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO delvauxo;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO delvauxo;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO delvauxo;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO delvauxo;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.fed_user_attribute OWNER TO delvauxo;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO delvauxo;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO delvauxo;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO delvauxo;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO delvauxo;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO delvauxo;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO delvauxo;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO delvauxo;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO delvauxo;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO delvauxo;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO delvauxo;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL,
    organization_id character varying(255),
    hide_on_login boolean DEFAULT false
);


ALTER TABLE public.identity_provider OWNER TO delvauxo;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO delvauxo;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO delvauxo;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO delvauxo;

--
-- Name: jgroups_ping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.jgroups_ping (
    address character varying(200) NOT NULL,
    name character varying(200),
    cluster_name character varying(200) NOT NULL,
    ip character varying(200) NOT NULL,
    coord boolean
);


ALTER TABLE public.jgroups_ping OWNER TO delvauxo;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36),
    type integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.keycloak_group OWNER TO delvauxo;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO delvauxo;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO delvauxo;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.offline_client_session OWNER TO delvauxo;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL,
    broker_session_id character varying(1024),
    version integer DEFAULT 0
);


ALTER TABLE public.offline_user_session OWNER TO delvauxo;

--
-- Name: org; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.org (
    id character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    realm_id character varying(255) NOT NULL,
    group_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(4000),
    alias character varying(255) NOT NULL,
    redirect_url character varying(2048)
);


ALTER TABLE public.org OWNER TO delvauxo;

--
-- Name: org_domain; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.org_domain (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    verified boolean NOT NULL,
    org_id character varying(255) NOT NULL
);


ALTER TABLE public.org_domain OWNER TO delvauxo;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO delvauxo;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO delvauxo;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO delvauxo;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO delvauxo;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO delvauxo;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO delvauxo;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO delvauxo;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO delvauxo;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO delvauxo;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO delvauxo;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO delvauxo;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO delvauxo;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO delvauxo;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO delvauxo;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO delvauxo;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO delvauxo;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO delvauxo;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO delvauxo;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_server (
    id character varying(36) NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO delvauxo;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO delvauxo;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO delvauxo;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO delvauxo;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO delvauxo;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO delvauxo;

--
-- Name: revoked_token; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.revoked_token (
    id character varying(255) NOT NULL,
    expire bigint NOT NULL
);


ALTER TABLE public.revoked_token OWNER TO delvauxo;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO delvauxo;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO delvauxo;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO delvauxo;

--
-- Name: server_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.server_config (
    server_config_key character varying(255) NOT NULL,
    value text NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.server_config OWNER TO delvauxo;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.user_attribute OWNER TO delvauxo;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO delvauxo;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO delvauxo;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO delvauxo;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO delvauxo;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO delvauxo;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO delvauxo;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO delvauxo;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    membership_type character varying(255) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO delvauxo;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO delvauxo;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO delvauxo;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO delvauxo;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type, details_json) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
5ed6f2d0-58c3-4dbe-ab91-f39b34be9b37	\N	auth-cookie	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	4825d051-4802-4fda-84ec-6331b657cc4a	2	10	f	\N	\N
841f05aa-3108-4217-bdc3-d30f143dc7a1	\N	auth-spnego	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	4825d051-4802-4fda-84ec-6331b657cc4a	3	20	f	\N	\N
ca6f13ae-52b3-4b92-b1ce-f259b3049bab	\N	identity-provider-redirector	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	4825d051-4802-4fda-84ec-6331b657cc4a	2	25	f	\N	\N
93402f15-0746-44fe-a17a-2afdda3e9f10	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	4825d051-4802-4fda-84ec-6331b657cc4a	2	30	t	171dcde2-c33b-42cc-9fd9-da6cf08fac30	\N
dd45d7da-c885-499d-897b-93d97ff1d14b	\N	auth-username-password-form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	171dcde2-c33b-42cc-9fd9-da6cf08fac30	0	10	f	\N	\N
46ba2df2-0491-438d-8d21-246134abe962	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	171dcde2-c33b-42cc-9fd9-da6cf08fac30	1	20	t	d97add5f-52ed-4f7d-baa0-761b8176f51e	\N
5c2031a8-9b97-4a49-98d5-f1dd7f0f4f5d	\N	conditional-user-configured	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	d97add5f-52ed-4f7d-baa0-761b8176f51e	0	10	f	\N	\N
251b1a71-efdf-449e-868b-5af3d4e08fb7	\N	auth-otp-form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	d97add5f-52ed-4f7d-baa0-761b8176f51e	0	20	f	\N	\N
7bbdb12c-aa1b-487a-928e-2c2ffdd9aac1	\N	direct-grant-validate-username	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	0c617b1a-9155-4003-a07a-014bbf07ed8b	0	10	f	\N	\N
4f0ee61c-d5f6-4910-88d6-0ce9cfb9d4c2	\N	direct-grant-validate-password	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	0c617b1a-9155-4003-a07a-014bbf07ed8b	0	20	f	\N	\N
046817d0-ef83-4d6e-99f6-47d8098d431d	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	0c617b1a-9155-4003-a07a-014bbf07ed8b	1	30	t	7f80feee-aa7d-4935-a5bf-f26666873348	\N
90baaa3d-8cb7-42de-8f53-4bf4b3891cf1	\N	conditional-user-configured	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7f80feee-aa7d-4935-a5bf-f26666873348	0	10	f	\N	\N
03b740ae-e61e-4be1-bfe2-b87487f769dd	\N	direct-grant-validate-otp	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7f80feee-aa7d-4935-a5bf-f26666873348	0	20	f	\N	\N
90201c59-2329-4883-bce4-21d61a72fdb9	\N	registration-page-form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	52cf7491-c40e-4e24-b418-f1a628589451	0	10	t	f4417464-7244-4409-9597-cb0fb8878279	\N
f340ce21-0686-4d88-a2b3-323551ad9311	\N	registration-user-creation	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f4417464-7244-4409-9597-cb0fb8878279	0	20	f	\N	\N
300852f0-d246-4232-8db2-d6fc0e11fd21	\N	registration-password-action	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f4417464-7244-4409-9597-cb0fb8878279	0	50	f	\N	\N
da486f93-2a2f-4ec5-b66f-a326be2587a1	\N	registration-recaptcha-action	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f4417464-7244-4409-9597-cb0fb8878279	3	60	f	\N	\N
7517a92c-5a07-478e-ac75-4abbd41be4f3	\N	registration-terms-and-conditions	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f4417464-7244-4409-9597-cb0fb8878279	3	70	f	\N	\N
ab49834f-ef19-4a55-8e61-b8bea5db6024	\N	reset-credentials-choose-user	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	3388ba99-da5a-4959-b4b5-9c7a3da98ffd	0	10	f	\N	\N
78aea423-c2c0-457e-afd1-824bfa36fbf1	\N	reset-credential-email	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	3388ba99-da5a-4959-b4b5-9c7a3da98ffd	0	20	f	\N	\N
50827962-3db5-4d23-92ff-e81157a2dad9	\N	reset-password	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	3388ba99-da5a-4959-b4b5-9c7a3da98ffd	0	30	f	\N	\N
a7da8cf1-9f80-4c65-8749-85a15395c00b	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	3388ba99-da5a-4959-b4b5-9c7a3da98ffd	1	40	t	f0155f7b-1f46-464a-b8a8-830f201b623b	\N
460cbb94-a85b-4413-8a83-445f0dd74e8e	\N	conditional-user-configured	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f0155f7b-1f46-464a-b8a8-830f201b623b	0	10	f	\N	\N
c3d7714c-3e7f-4687-9c62-e0e1fba334cf	\N	reset-otp	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f0155f7b-1f46-464a-b8a8-830f201b623b	0	20	f	\N	\N
b1dab5ab-c41a-4a08-a734-245034311374	\N	client-secret	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f6fc3b14-b7c4-4384-91bf-2eeaede7b390	2	10	f	\N	\N
15ebebbe-0d2f-4f15-a8da-e5247e634164	\N	client-jwt	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f6fc3b14-b7c4-4384-91bf-2eeaede7b390	2	20	f	\N	\N
71bbedfd-3292-4e68-8287-d5a100111df2	\N	client-secret-jwt	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f6fc3b14-b7c4-4384-91bf-2eeaede7b390	2	30	f	\N	\N
6e301567-4b54-4cb7-bec8-87412fca69f6	\N	client-x509	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f6fc3b14-b7c4-4384-91bf-2eeaede7b390	2	40	f	\N	\N
163cf27a-c6f3-42a4-9f35-9449c2150f78	\N	idp-review-profile	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	aa29d358-ba88-4eed-bb4f-c2526d4b4fcb	0	10	f	\N	c4476e6a-58b7-41ed-8b70-a9ba22594401
b46272ac-8c81-4d6e-a105-35605d833505	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	aa29d358-ba88-4eed-bb4f-c2526d4b4fcb	0	20	t	fe6d7273-11fc-4627-b1a4-7f6148aa3348	\N
14b0d4a6-93b1-4545-9f9e-8263b0f396bc	\N	idp-create-user-if-unique	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	fe6d7273-11fc-4627-b1a4-7f6148aa3348	2	10	f	\N	0f00f0bd-3e07-4464-9352-6b4ea93deec0
f907fb51-77bc-4ef3-8a98-d0874892127e	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	fe6d7273-11fc-4627-b1a4-7f6148aa3348	2	20	t	ba544a3a-1fa7-40e7-aab0-bd88f7e1712d	\N
1864c55c-1866-459b-835f-75492b1935ed	\N	idp-confirm-link	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	ba544a3a-1fa7-40e7-aab0-bd88f7e1712d	0	10	f	\N	\N
01ab5829-8c24-4f31-83f2-8203ebffa0d6	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	ba544a3a-1fa7-40e7-aab0-bd88f7e1712d	0	20	t	cb2a43e0-6f43-4d6d-8a51-7c6e4a224e71	\N
41716f75-29eb-42c1-bce7-4635308d06a2	\N	idp-email-verification	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	cb2a43e0-6f43-4d6d-8a51-7c6e4a224e71	2	10	f	\N	\N
b79477fc-4c62-4e5d-be1b-fde38071136f	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	cb2a43e0-6f43-4d6d-8a51-7c6e4a224e71	2	20	t	2308a3d4-d29a-4499-8123-708df86966ed	\N
eecf0d91-36df-4d10-9212-4f309363349b	\N	idp-username-password-form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	2308a3d4-d29a-4499-8123-708df86966ed	0	10	f	\N	\N
f426c10f-13e6-4195-ab55-1b02c86f1e07	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	2308a3d4-d29a-4499-8123-708df86966ed	1	20	t	cd8531c8-0e1d-4f8f-8ed3-122183fab892	\N
38f8890c-2218-4140-aa2f-d603e61d1201	\N	conditional-user-configured	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	cd8531c8-0e1d-4f8f-8ed3-122183fab892	0	10	f	\N	\N
7a1437f7-adab-4384-aaf2-eb97ee79e4b0	\N	auth-otp-form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	cd8531c8-0e1d-4f8f-8ed3-122183fab892	0	20	f	\N	\N
66e0892f-2c71-4d0e-979c-0b2f45f6d4e0	\N	http-basic-authenticator	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	8c885954-ae8e-4f26-9b8d-3aa7cffeb3b1	0	10	f	\N	\N
c12a982c-28b1-44a3-8cb4-add060aebb51	\N	docker-http-basic-authenticator	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	dd3a2e04-08e0-47a2-86c3-e36656a7550e	0	10	f	\N	\N
7d231091-1761-4664-bb62-34d39e72c10c	\N	auth-cookie	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4c76e54e-be78-4feb-ad59-d346f4cfbe64	2	10	f	\N	\N
bf0f5aa7-7ad3-4121-8690-9ea5b6f29765	\N	auth-spnego	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4c76e54e-be78-4feb-ad59-d346f4cfbe64	3	20	f	\N	\N
83bda606-c274-4bdf-8f18-ad221858953c	\N	identity-provider-redirector	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4c76e54e-be78-4feb-ad59-d346f4cfbe64	2	25	f	\N	\N
82f5827d-fd3c-4502-9b02-0202acb3d451	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4c76e54e-be78-4feb-ad59-d346f4cfbe64	2	30	t	efb3c05a-032f-4063-9ac4-661da5405bc5	\N
1d364015-27ba-4b7a-a68a-2dbef0bd3362	\N	auth-username-password-form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	efb3c05a-032f-4063-9ac4-661da5405bc5	0	10	f	\N	\N
c6bd6b18-56c5-41d3-aa59-c69200834c61	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	efb3c05a-032f-4063-9ac4-661da5405bc5	1	20	t	01b96c10-197d-4889-b8a3-de47fc43eeb9	\N
c4e6387b-ccf7-4070-933d-ce8eb4623907	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	01b96c10-197d-4889-b8a3-de47fc43eeb9	0	10	f	\N	\N
771a07c1-d2f7-4707-bba7-8309e9bce6b8	\N	auth-otp-form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	01b96c10-197d-4889-b8a3-de47fc43eeb9	0	20	f	\N	\N
cd689f2d-2219-48c0-86d2-689832b1db44	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4c76e54e-be78-4feb-ad59-d346f4cfbe64	2	26	t	fe382766-e114-497a-937c-42c83f26cf89	\N
84b2c140-a354-422d-956c-b31dba028a4a	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	fe382766-e114-497a-937c-42c83f26cf89	1	10	t	c370398d-590b-4e7e-873e-6a8f86293e78	\N
dad7bf10-b44f-4115-9d9e-f962ef29cc7d	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	c370398d-590b-4e7e-873e-6a8f86293e78	0	10	f	\N	\N
2fe19951-7c44-4e54-ac3b-f8e11daff0f3	\N	organization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	c370398d-590b-4e7e-873e-6a8f86293e78	2	20	f	\N	\N
8784582f-fb60-49ce-ae7a-5019b1dbaa73	\N	direct-grant-validate-username	b8bb26cb-496e-4ae0-94bc-8c9268be7494	91dbd84c-361e-41b2-a4c5-f092eff56c47	0	10	f	\N	\N
b2098783-3e51-466a-ae3a-1ea4664a8b69	\N	direct-grant-validate-password	b8bb26cb-496e-4ae0-94bc-8c9268be7494	91dbd84c-361e-41b2-a4c5-f092eff56c47	0	20	f	\N	\N
2ae75ce6-0e64-4b3d-b89d-e188060be06e	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	91dbd84c-361e-41b2-a4c5-f092eff56c47	1	30	t	1319c6e3-5cb0-4379-ad50-e9f1e9e91d8f	\N
aa24bd29-3d1d-4462-a850-f96fd7d3e7c8	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	1319c6e3-5cb0-4379-ad50-e9f1e9e91d8f	0	10	f	\N	\N
f460d17e-c2b2-4b3f-8c7a-a6f02541d9cd	\N	direct-grant-validate-otp	b8bb26cb-496e-4ae0-94bc-8c9268be7494	1319c6e3-5cb0-4379-ad50-e9f1e9e91d8f	0	20	f	\N	\N
f69e3c0b-6835-45e2-b723-b3afc5a3b0c0	\N	registration-page-form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	ec4be730-d525-4c2b-be48-23483b54b460	0	10	t	288953d7-bbf6-495f-ac26-fffc16375f4e	\N
a9128798-d58b-4b0a-90ab-8a04484c4b34	\N	registration-user-creation	b8bb26cb-496e-4ae0-94bc-8c9268be7494	288953d7-bbf6-495f-ac26-fffc16375f4e	0	20	f	\N	\N
07648f90-1e10-45f0-830f-959ab149baf5	\N	registration-password-action	b8bb26cb-496e-4ae0-94bc-8c9268be7494	288953d7-bbf6-495f-ac26-fffc16375f4e	0	50	f	\N	\N
f3d24f9e-3780-4615-b22b-eb2d5606ed12	\N	registration-recaptcha-action	b8bb26cb-496e-4ae0-94bc-8c9268be7494	288953d7-bbf6-495f-ac26-fffc16375f4e	3	60	f	\N	\N
dcbba60c-168e-4f50-a227-3fb30daf2928	\N	registration-terms-and-conditions	b8bb26cb-496e-4ae0-94bc-8c9268be7494	288953d7-bbf6-495f-ac26-fffc16375f4e	3	70	f	\N	\N
ec1e66a4-48ff-44d9-a281-38bb2fae7e60	\N	reset-credentials-choose-user	b8bb26cb-496e-4ae0-94bc-8c9268be7494	08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	0	10	f	\N	\N
8ba1c9d0-1e7f-46b8-9625-4a92d7393fd4	\N	reset-credential-email	b8bb26cb-496e-4ae0-94bc-8c9268be7494	08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	0	20	f	\N	\N
9f8ebed2-a121-4330-989e-4bbf15329226	\N	reset-password	b8bb26cb-496e-4ae0-94bc-8c9268be7494	08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	0	30	f	\N	\N
4f95cb17-8367-4588-a300-7af699c71c54	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	1	40	t	815d9c19-2e4b-4ed5-8566-a2efc44797b3	\N
6f2873cc-9f4d-4c5c-a23d-d66e40457d79	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	815d9c19-2e4b-4ed5-8566-a2efc44797b3	0	10	f	\N	\N
32a4a82d-2d3f-4176-bc5f-c84578392985	\N	reset-otp	b8bb26cb-496e-4ae0-94bc-8c9268be7494	815d9c19-2e4b-4ed5-8566-a2efc44797b3	0	20	f	\N	\N
fe076800-7415-4842-a8dc-4df9d8ec1b50	\N	client-secret	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f4a38d03-32e0-44ba-828d-561f926dd9aa	2	10	f	\N	\N
58eb5e26-a6e1-444f-b279-6a818d0f3c7e	\N	client-jwt	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f4a38d03-32e0-44ba-828d-561f926dd9aa	2	20	f	\N	\N
d4c802eb-e69b-49f0-bfc5-d51a28c148af	\N	client-secret-jwt	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f4a38d03-32e0-44ba-828d-561f926dd9aa	2	30	f	\N	\N
fed9c2dc-dfe0-4acd-b093-755172dc8a9b	\N	client-x509	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f4a38d03-32e0-44ba-828d-561f926dd9aa	2	40	f	\N	\N
5d999ccc-647a-48cc-bcbe-49b52b26c1ca	\N	idp-review-profile	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4edff1f2-2f5c-4a25-8ca5-fa43f072f9a2	0	10	f	\N	eb0f79d7-ad26-48eb-87dc-059102fca0cf
3b1215f3-23a4-4198-8022-28303cca38f5	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4edff1f2-2f5c-4a25-8ca5-fa43f072f9a2	0	20	t	1b49c416-a7e9-449e-b81e-c081e1a75c60	\N
6508a21a-e12b-4e47-834c-492e2c199e7c	\N	idp-create-user-if-unique	b8bb26cb-496e-4ae0-94bc-8c9268be7494	1b49c416-a7e9-449e-b81e-c081e1a75c60	2	10	f	\N	c29547cd-5340-4a51-a060-8fdcafc517aa
d452a260-1ba2-431a-991b-613d57270302	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	1b49c416-a7e9-449e-b81e-c081e1a75c60	2	20	t	de704910-8588-46ff-bc6c-d9a41269a13d	\N
527e359b-1c96-4ef2-b4f7-b5462d1879af	\N	idp-confirm-link	b8bb26cb-496e-4ae0-94bc-8c9268be7494	de704910-8588-46ff-bc6c-d9a41269a13d	0	10	f	\N	\N
a1abfd90-9577-40db-bb23-1819accbc341	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	de704910-8588-46ff-bc6c-d9a41269a13d	0	20	t	ae61e768-9c6c-4a4b-97b3-e714ffab42a4	\N
55779147-3251-463e-8dbe-f3e8b05194a0	\N	idp-email-verification	b8bb26cb-496e-4ae0-94bc-8c9268be7494	ae61e768-9c6c-4a4b-97b3-e714ffab42a4	2	10	f	\N	\N
05b837bd-dc8a-4688-9eec-94786746864c	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	ae61e768-9c6c-4a4b-97b3-e714ffab42a4	2	20	t	41d79ec4-a8d5-49d1-a989-380eeb65000d	\N
2a5c32d4-d343-4a72-8792-93d46defcf15	\N	idp-username-password-form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	41d79ec4-a8d5-49d1-a989-380eeb65000d	0	10	f	\N	\N
d197cc69-ff2a-41c7-ac8b-1502a236f839	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	41d79ec4-a8d5-49d1-a989-380eeb65000d	1	20	t	b9bd9271-9b0a-4fd4-ae9f-4d602ef14f8e	\N
1d165324-c8f0-4265-b2b5-51e3a3ea7489	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	b9bd9271-9b0a-4fd4-ae9f-4d602ef14f8e	0	10	f	\N	\N
1c67307b-5be9-4568-a6e7-18e1faa468b5	\N	auth-otp-form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	b9bd9271-9b0a-4fd4-ae9f-4d602ef14f8e	0	20	f	\N	\N
e47fb0cb-b45a-43b9-a3b8-e69dd596557e	\N	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4edff1f2-2f5c-4a25-8ca5-fa43f072f9a2	1	50	t	19c531d4-ad59-4e6c-9eee-05e6dde620a3	\N
ef58ff76-82ae-4762-983c-8575bf8e6350	\N	conditional-user-configured	b8bb26cb-496e-4ae0-94bc-8c9268be7494	19c531d4-ad59-4e6c-9eee-05e6dde620a3	0	10	f	\N	\N
25a19e2e-ed88-4a93-b08d-891edb4e3640	\N	idp-add-organization-member	b8bb26cb-496e-4ae0-94bc-8c9268be7494	19c531d4-ad59-4e6c-9eee-05e6dde620a3	0	20	f	\N	\N
0662266a-1268-4add-98ed-f723efc1057e	\N	http-basic-authenticator	b8bb26cb-496e-4ae0-94bc-8c9268be7494	69d659d2-926c-4853-8e3a-3f63007f405c	0	10	f	\N	\N
b664f344-5236-423a-802f-704906bdd842	\N	docker-http-basic-authenticator	b8bb26cb-496e-4ae0-94bc-8c9268be7494	d767940b-7f44-4bfb-848c-768a11f3cc93	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
4825d051-4802-4fda-84ec-6331b657cc4a	browser	Browser based authentication	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
171dcde2-c33b-42cc-9fd9-da6cf08fac30	forms	Username, password, otp and other auth forms.	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
d97add5f-52ed-4f7d-baa0-761b8176f51e	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
0c617b1a-9155-4003-a07a-014bbf07ed8b	direct grant	OpenID Connect Resource Owner Grant	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
7f80feee-aa7d-4935-a5bf-f26666873348	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
52cf7491-c40e-4e24-b418-f1a628589451	registration	Registration flow	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
f4417464-7244-4409-9597-cb0fb8878279	registration form	Registration form	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	form-flow	f	t
3388ba99-da5a-4959-b4b5-9c7a3da98ffd	reset credentials	Reset credentials for a user if they forgot their password or something	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
f0155f7b-1f46-464a-b8a8-830f201b623b	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
f6fc3b14-b7c4-4384-91bf-2eeaede7b390	clients	Base authentication for clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	client-flow	t	t
aa29d358-ba88-4eed-bb4f-c2526d4b4fcb	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
fe6d7273-11fc-4627-b1a4-7f6148aa3348	User creation or linking	Flow for the existing/non-existing user alternatives	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
ba544a3a-1fa7-40e7-aab0-bd88f7e1712d	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
cb2a43e0-6f43-4d6d-8a51-7c6e4a224e71	Account verification options	Method with which to verity the existing account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
2308a3d4-d29a-4499-8123-708df86966ed	Verify Existing Account by Re-authentication	Reauthentication of existing account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
cd8531c8-0e1d-4f8f-8ed3-122183fab892	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	f	t
8c885954-ae8e-4f26-9b8d-3aa7cffeb3b1	saml ecp	SAML ECP Profile Authentication Flow	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
dd3a2e04-08e0-47a2-86c3-e36656a7550e	docker auth	Used by Docker clients to authenticate against the IDP	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	basic-flow	t	t
4c76e54e-be78-4feb-ad59-d346f4cfbe64	browser	Browser based authentication	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
efb3c05a-032f-4063-9ac4-661da5405bc5	forms	Username, password, otp and other auth forms.	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
01b96c10-197d-4889-b8a3-de47fc43eeb9	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
fe382766-e114-497a-937c-42c83f26cf89	Organization	\N	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
c370398d-590b-4e7e-873e-6a8f86293e78	Browser - Conditional Organization	Flow to determine if the organization identity-first login is to be used	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
91dbd84c-361e-41b2-a4c5-f092eff56c47	direct grant	OpenID Connect Resource Owner Grant	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
1319c6e3-5cb0-4379-ad50-e9f1e9e91d8f	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
ec4be730-d525-4c2b-be48-23483b54b460	registration	Registration flow	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
288953d7-bbf6-495f-ac26-fffc16375f4e	registration form	Registration form	b8bb26cb-496e-4ae0-94bc-8c9268be7494	form-flow	f	t
08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	reset credentials	Reset credentials for a user if they forgot their password or something	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
815d9c19-2e4b-4ed5-8566-a2efc44797b3	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
f4a38d03-32e0-44ba-828d-561f926dd9aa	clients	Base authentication for clients	b8bb26cb-496e-4ae0-94bc-8c9268be7494	client-flow	t	t
4edff1f2-2f5c-4a25-8ca5-fa43f072f9a2	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
1b49c416-a7e9-449e-b81e-c081e1a75c60	User creation or linking	Flow for the existing/non-existing user alternatives	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
de704910-8588-46ff-bc6c-d9a41269a13d	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
ae61e768-9c6c-4a4b-97b3-e714ffab42a4	Account verification options	Method with which to verity the existing account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
41d79ec4-a8d5-49d1-a989-380eeb65000d	Verify Existing Account by Re-authentication	Reauthentication of existing account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
b9bd9271-9b0a-4fd4-ae9f-4d602ef14f8e	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
19c531d4-ad59-4e6c-9eee-05e6dde620a3	First Broker Login - Conditional Organization	Flow to determine if the authenticator that adds organization members is to be used	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	f	t
69d659d2-926c-4853-8e3a-3f63007f405c	saml ecp	SAML ECP Profile Authentication Flow	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
d767940b-7f44-4bfb-848c-768a11f3cc93	docker auth	Used by Docker clients to authenticate against the IDP	b8bb26cb-496e-4ae0-94bc-8c9268be7494	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
c4476e6a-58b7-41ed-8b70-a9ba22594401	review profile config	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20
0f00f0bd-3e07-4464-9352-6b4ea93deec0	create unique user config	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20
eb0f79d7-ad26-48eb-87dc-059102fca0cf	review profile config	b8bb26cb-496e-4ae0-94bc-8c9268be7494
c29547cd-5340-4a51-a060-8fdcafc517aa	create unique user config	b8bb26cb-496e-4ae0-94bc-8c9268be7494
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
0f00f0bd-3e07-4464-9352-6b4ea93deec0	false	require.password.update.after.registration
c4476e6a-58b7-41ed-8b70-a9ba22594401	missing	update.profile.on.first.login
c29547cd-5340-4a51-a060-8fdcafc517aa	false	require.password.update.after.registration
eb0f79d7-ad26-48eb-87dc-059102fca0cf	missing	update.profile.on.first.login
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
7ec446a5-c642-4994-b419-0806329b58bf	t	f	master-realm	0	f	\N	\N	t	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
0f762526-c25a-452c-92f9-6c00cbc28295	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
65973d02-362c-4c14-87c6-20fe07c58f5f	t	f	broker	0	f	\N	\N	t	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	t	t	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
3de82151-b989-4126-8991-5fad88e38310	t	t	admin-cli	0	t	\N	\N	f	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	f	nextjs-dashboard-realm	0	f	\N	\N	t	\N	f	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	0	f	f	nextjs-dashboard Realm	f	client-secret	\N	\N	\N	t	f	f	f
425e27a1-0201-4864-a8da-1389309f3991	t	f	realm-management	0	f	\N	\N	t	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
93f2c134-c670-4909-985e-fe010ba0387f	t	f	account	0	t	\N	/realms/nextjs-dashboard/account/	f	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
da945e89-e174-4986-8638-ede57a2b5c50	t	f	account-console	0	t	\N	/realms/nextjs-dashboard/account/	f	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
d022457d-23f0-43de-a367-5764a1002542	t	f	broker	0	f	\N	\N	t	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	t	t	security-admin-console	0	t	\N	/admin/nextjs-dashboard/console/	f	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	t	t	admin-cli	0	t	\N	\N	f	\N	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
b658886f-d909-4c90-b9d9-567d24212b2c	t	t	parkigo	0	f	EizZfQy12vFin9Nzty0ro6tGQockUbBl	\N	f	http://localhost:3000	f	b8bb26cb-496e-4ae0-94bc-8c9268be7494	openid-connect	-1	f	f	\N	f	client-secret	http://localhost:3000	\N	\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	post.logout.redirect.uris	+
0f762526-c25a-452c-92f9-6c00cbc28295	post.logout.redirect.uris	+
0f762526-c25a-452c-92f9-6c00cbc28295	pkce.code.challenge.method	S256
70e2e715-8e79-4b85-979a-9b96a357ddb9	post.logout.redirect.uris	+
70e2e715-8e79-4b85-979a-9b96a357ddb9	pkce.code.challenge.method	S256
70e2e715-8e79-4b85-979a-9b96a357ddb9	client.use.lightweight.access.token.enabled	true
3de82151-b989-4126-8991-5fad88e38310	client.use.lightweight.access.token.enabled	true
93f2c134-c670-4909-985e-fe010ba0387f	post.logout.redirect.uris	+
da945e89-e174-4986-8638-ede57a2b5c50	post.logout.redirect.uris	+
da945e89-e174-4986-8638-ede57a2b5c50	pkce.code.challenge.method	S256
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	post.logout.redirect.uris	+
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	pkce.code.challenge.method	S256
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	client.use.lightweight.access.token.enabled	true
7202d349-c06e-4082-a8dd-ca723ae82dfd	client.use.lightweight.access.token.enabled	true
b658886f-d909-4c90-b9d9-567d24212b2c	post.logout.redirect.uris	+
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
2d130128-6b0f-4a1c-935a-f8761a4ab63f	offline_access	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect built-in scope: offline_access	openid-connect
d7a8c698-f0b2-4433-a2be-b06cea303ee7	role_list	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	SAML role list	saml
cd9b2dff-e030-44bd-814d-bf7ae7e0de3b	saml_organization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	Organization Membership	saml
c6266124-fda5-40ae-9d53-f2fad8c47976	profile	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect built-in scope: profile	openid-connect
6cd5db78-03b2-493f-81ba-e4acd74e44c6	email	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect built-in scope: email	openid-connect
53075a4e-df7c-45c3-ae11-b1280ac1d580	address	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect built-in scope: address	openid-connect
d021eb96-7654-4a18-ad38-8f5ad86baf24	phone	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect built-in scope: phone	openid-connect
796d1d68-2914-4b36-bffb-4580c977ea54	roles	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect scope for add user roles to the access token	openid-connect
86b56408-5c52-4f25-9da8-ad51cb65e26d	web-origins	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect scope for add allowed web origins to the access token	openid-connect
fbca5fcb-7ba3-4e9d-93a3-adf0298de659	microprofile-jwt	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	Microprofile - JWT built-in scope	openid-connect
23a98e55-01e9-4cee-8696-7cbbc1d6138f	acr	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
15c66c27-1086-419b-bad2-a27ceead1dc0	basic	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	OpenID Connect scope for add all basic claims to the token	openid-connect
d9fa4350-de11-428e-b2fa-68019bd14976	service_account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	Specific scope for a client enabled for service accounts	openid-connect
571471a6-1e27-4d71-801b-c842c2dc11ca	organization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	Additional claims about the organization a subject belongs to	openid-connect
21862a5a-767c-4bc6-9863-935998fb4070	offline_access	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect built-in scope: offline_access	openid-connect
c4eee212-112e-496f-b99d-537a786c7843	role_list	b8bb26cb-496e-4ae0-94bc-8c9268be7494	SAML role list	saml
46565aae-25e5-4451-a443-c13556dd571e	saml_organization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	Organization Membership	saml
61b5ebfc-2783-4c4f-a746-5408cce8bdeb	profile	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect built-in scope: profile	openid-connect
a7ece06c-6983-4c98-8f8d-a4559293c529	email	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect built-in scope: email	openid-connect
cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	address	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect built-in scope: address	openid-connect
89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	phone	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect built-in scope: phone	openid-connect
661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	roles	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect scope for add user roles to the access token	openid-connect
103fde5b-c40b-413a-a01e-ee8c04cc6efd	web-origins	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect scope for add allowed web origins to the access token	openid-connect
ddefb625-6062-446d-804c-72b962e7f330	microprofile-jwt	b8bb26cb-496e-4ae0-94bc-8c9268be7494	Microprofile - JWT built-in scope	openid-connect
2464429d-4856-4d59-976f-40e1e066fa19	acr	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
364149a4-5707-4969-a163-224dc227ec55	basic	b8bb26cb-496e-4ae0-94bc-8c9268be7494	OpenID Connect scope for add all basic claims to the token	openid-connect
f80d48ca-4a8d-4418-b062-3a463dc6eff8	service_account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	Specific scope for a client enabled for service accounts	openid-connect
77e2ccf9-8143-4935-9800-9986feb17b01	organization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	Additional claims about the organization a subject belongs to	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
2d130128-6b0f-4a1c-935a-f8761a4ab63f	true	display.on.consent.screen
2d130128-6b0f-4a1c-935a-f8761a4ab63f	${offlineAccessScopeConsentText}	consent.screen.text
d7a8c698-f0b2-4433-a2be-b06cea303ee7	true	display.on.consent.screen
d7a8c698-f0b2-4433-a2be-b06cea303ee7	${samlRoleListScopeConsentText}	consent.screen.text
cd9b2dff-e030-44bd-814d-bf7ae7e0de3b	false	display.on.consent.screen
c6266124-fda5-40ae-9d53-f2fad8c47976	true	display.on.consent.screen
c6266124-fda5-40ae-9d53-f2fad8c47976	${profileScopeConsentText}	consent.screen.text
c6266124-fda5-40ae-9d53-f2fad8c47976	true	include.in.token.scope
6cd5db78-03b2-493f-81ba-e4acd74e44c6	true	display.on.consent.screen
6cd5db78-03b2-493f-81ba-e4acd74e44c6	${emailScopeConsentText}	consent.screen.text
6cd5db78-03b2-493f-81ba-e4acd74e44c6	true	include.in.token.scope
53075a4e-df7c-45c3-ae11-b1280ac1d580	true	display.on.consent.screen
53075a4e-df7c-45c3-ae11-b1280ac1d580	${addressScopeConsentText}	consent.screen.text
53075a4e-df7c-45c3-ae11-b1280ac1d580	true	include.in.token.scope
d021eb96-7654-4a18-ad38-8f5ad86baf24	true	display.on.consent.screen
d021eb96-7654-4a18-ad38-8f5ad86baf24	${phoneScopeConsentText}	consent.screen.text
d021eb96-7654-4a18-ad38-8f5ad86baf24	true	include.in.token.scope
796d1d68-2914-4b36-bffb-4580c977ea54	true	display.on.consent.screen
796d1d68-2914-4b36-bffb-4580c977ea54	${rolesScopeConsentText}	consent.screen.text
796d1d68-2914-4b36-bffb-4580c977ea54	false	include.in.token.scope
86b56408-5c52-4f25-9da8-ad51cb65e26d	false	display.on.consent.screen
86b56408-5c52-4f25-9da8-ad51cb65e26d		consent.screen.text
86b56408-5c52-4f25-9da8-ad51cb65e26d	false	include.in.token.scope
fbca5fcb-7ba3-4e9d-93a3-adf0298de659	false	display.on.consent.screen
fbca5fcb-7ba3-4e9d-93a3-adf0298de659	true	include.in.token.scope
23a98e55-01e9-4cee-8696-7cbbc1d6138f	false	display.on.consent.screen
23a98e55-01e9-4cee-8696-7cbbc1d6138f	false	include.in.token.scope
15c66c27-1086-419b-bad2-a27ceead1dc0	false	display.on.consent.screen
15c66c27-1086-419b-bad2-a27ceead1dc0	false	include.in.token.scope
d9fa4350-de11-428e-b2fa-68019bd14976	false	display.on.consent.screen
d9fa4350-de11-428e-b2fa-68019bd14976	false	include.in.token.scope
571471a6-1e27-4d71-801b-c842c2dc11ca	true	display.on.consent.screen
571471a6-1e27-4d71-801b-c842c2dc11ca	${organizationScopeConsentText}	consent.screen.text
571471a6-1e27-4d71-801b-c842c2dc11ca	true	include.in.token.scope
21862a5a-767c-4bc6-9863-935998fb4070	true	display.on.consent.screen
21862a5a-767c-4bc6-9863-935998fb4070	${offlineAccessScopeConsentText}	consent.screen.text
c4eee212-112e-496f-b99d-537a786c7843	true	display.on.consent.screen
c4eee212-112e-496f-b99d-537a786c7843	${samlRoleListScopeConsentText}	consent.screen.text
46565aae-25e5-4451-a443-c13556dd571e	false	display.on.consent.screen
61b5ebfc-2783-4c4f-a746-5408cce8bdeb	true	display.on.consent.screen
61b5ebfc-2783-4c4f-a746-5408cce8bdeb	${profileScopeConsentText}	consent.screen.text
61b5ebfc-2783-4c4f-a746-5408cce8bdeb	true	include.in.token.scope
a7ece06c-6983-4c98-8f8d-a4559293c529	true	display.on.consent.screen
a7ece06c-6983-4c98-8f8d-a4559293c529	${emailScopeConsentText}	consent.screen.text
a7ece06c-6983-4c98-8f8d-a4559293c529	true	include.in.token.scope
cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	true	display.on.consent.screen
cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	${addressScopeConsentText}	consent.screen.text
cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	true	include.in.token.scope
89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	true	display.on.consent.screen
89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	${phoneScopeConsentText}	consent.screen.text
89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	true	include.in.token.scope
661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	true	display.on.consent.screen
661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	${rolesScopeConsentText}	consent.screen.text
661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	false	include.in.token.scope
103fde5b-c40b-413a-a01e-ee8c04cc6efd	false	display.on.consent.screen
103fde5b-c40b-413a-a01e-ee8c04cc6efd		consent.screen.text
103fde5b-c40b-413a-a01e-ee8c04cc6efd	false	include.in.token.scope
ddefb625-6062-446d-804c-72b962e7f330	false	display.on.consent.screen
ddefb625-6062-446d-804c-72b962e7f330	true	include.in.token.scope
2464429d-4856-4d59-976f-40e1e066fa19	false	display.on.consent.screen
2464429d-4856-4d59-976f-40e1e066fa19	false	include.in.token.scope
364149a4-5707-4969-a163-224dc227ec55	false	display.on.consent.screen
364149a4-5707-4969-a163-224dc227ec55	false	include.in.token.scope
f80d48ca-4a8d-4418-b062-3a463dc6eff8	false	display.on.consent.screen
f80d48ca-4a8d-4418-b062-3a463dc6eff8	false	include.in.token.scope
77e2ccf9-8143-4935-9800-9986feb17b01	true	display.on.consent.screen
77e2ccf9-8143-4935-9800-9986feb17b01	${organizationScopeConsentText}	consent.screen.text
77e2ccf9-8143-4935-9800-9986feb17b01	true	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	15c66c27-1086-419b-bad2-a27ceead1dc0	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	c6266124-fda5-40ae-9d53-f2fad8c47976	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	796d1d68-2914-4b36-bffb-4580c977ea54	t
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	571471a6-1e27-4d71-801b-c842c2dc11ca	f
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
0f762526-c25a-452c-92f9-6c00cbc28295	15c66c27-1086-419b-bad2-a27ceead1dc0	t
0f762526-c25a-452c-92f9-6c00cbc28295	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
0f762526-c25a-452c-92f9-6c00cbc28295	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
0f762526-c25a-452c-92f9-6c00cbc28295	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
0f762526-c25a-452c-92f9-6c00cbc28295	c6266124-fda5-40ae-9d53-f2fad8c47976	t
0f762526-c25a-452c-92f9-6c00cbc28295	796d1d68-2914-4b36-bffb-4580c977ea54	t
0f762526-c25a-452c-92f9-6c00cbc28295	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
0f762526-c25a-452c-92f9-6c00cbc28295	571471a6-1e27-4d71-801b-c842c2dc11ca	f
0f762526-c25a-452c-92f9-6c00cbc28295	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
0f762526-c25a-452c-92f9-6c00cbc28295	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
0f762526-c25a-452c-92f9-6c00cbc28295	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
3de82151-b989-4126-8991-5fad88e38310	15c66c27-1086-419b-bad2-a27ceead1dc0	t
3de82151-b989-4126-8991-5fad88e38310	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
3de82151-b989-4126-8991-5fad88e38310	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
3de82151-b989-4126-8991-5fad88e38310	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
3de82151-b989-4126-8991-5fad88e38310	c6266124-fda5-40ae-9d53-f2fad8c47976	t
3de82151-b989-4126-8991-5fad88e38310	796d1d68-2914-4b36-bffb-4580c977ea54	t
3de82151-b989-4126-8991-5fad88e38310	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
3de82151-b989-4126-8991-5fad88e38310	571471a6-1e27-4d71-801b-c842c2dc11ca	f
3de82151-b989-4126-8991-5fad88e38310	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
3de82151-b989-4126-8991-5fad88e38310	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
3de82151-b989-4126-8991-5fad88e38310	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
65973d02-362c-4c14-87c6-20fe07c58f5f	15c66c27-1086-419b-bad2-a27ceead1dc0	t
65973d02-362c-4c14-87c6-20fe07c58f5f	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
65973d02-362c-4c14-87c6-20fe07c58f5f	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
65973d02-362c-4c14-87c6-20fe07c58f5f	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
65973d02-362c-4c14-87c6-20fe07c58f5f	c6266124-fda5-40ae-9d53-f2fad8c47976	t
65973d02-362c-4c14-87c6-20fe07c58f5f	796d1d68-2914-4b36-bffb-4580c977ea54	t
65973d02-362c-4c14-87c6-20fe07c58f5f	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
65973d02-362c-4c14-87c6-20fe07c58f5f	571471a6-1e27-4d71-801b-c842c2dc11ca	f
65973d02-362c-4c14-87c6-20fe07c58f5f	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
65973d02-362c-4c14-87c6-20fe07c58f5f	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
65973d02-362c-4c14-87c6-20fe07c58f5f	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
7ec446a5-c642-4994-b419-0806329b58bf	15c66c27-1086-419b-bad2-a27ceead1dc0	t
7ec446a5-c642-4994-b419-0806329b58bf	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
7ec446a5-c642-4994-b419-0806329b58bf	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
7ec446a5-c642-4994-b419-0806329b58bf	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
7ec446a5-c642-4994-b419-0806329b58bf	c6266124-fda5-40ae-9d53-f2fad8c47976	t
7ec446a5-c642-4994-b419-0806329b58bf	796d1d68-2914-4b36-bffb-4580c977ea54	t
7ec446a5-c642-4994-b419-0806329b58bf	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
7ec446a5-c642-4994-b419-0806329b58bf	571471a6-1e27-4d71-801b-c842c2dc11ca	f
7ec446a5-c642-4994-b419-0806329b58bf	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
7ec446a5-c642-4994-b419-0806329b58bf	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
7ec446a5-c642-4994-b419-0806329b58bf	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	15c66c27-1086-419b-bad2-a27ceead1dc0	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	c6266124-fda5-40ae-9d53-f2fad8c47976	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	796d1d68-2914-4b36-bffb-4580c977ea54	t
70e2e715-8e79-4b85-979a-9b96a357ddb9	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	571471a6-1e27-4d71-801b-c842c2dc11ca	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
70e2e715-8e79-4b85-979a-9b96a357ddb9	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
93f2c134-c670-4909-985e-fe010ba0387f	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
93f2c134-c670-4909-985e-fe010ba0387f	364149a4-5707-4969-a163-224dc227ec55	t
93f2c134-c670-4909-985e-fe010ba0387f	a7ece06c-6983-4c98-8f8d-a4559293c529	t
93f2c134-c670-4909-985e-fe010ba0387f	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
93f2c134-c670-4909-985e-fe010ba0387f	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
93f2c134-c670-4909-985e-fe010ba0387f	2464429d-4856-4d59-976f-40e1e066fa19	t
93f2c134-c670-4909-985e-fe010ba0387f	ddefb625-6062-446d-804c-72b962e7f330	f
93f2c134-c670-4909-985e-fe010ba0387f	77e2ccf9-8143-4935-9800-9986feb17b01	f
93f2c134-c670-4909-985e-fe010ba0387f	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
93f2c134-c670-4909-985e-fe010ba0387f	21862a5a-767c-4bc6-9863-935998fb4070	f
93f2c134-c670-4909-985e-fe010ba0387f	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
da945e89-e174-4986-8638-ede57a2b5c50	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
da945e89-e174-4986-8638-ede57a2b5c50	364149a4-5707-4969-a163-224dc227ec55	t
da945e89-e174-4986-8638-ede57a2b5c50	a7ece06c-6983-4c98-8f8d-a4559293c529	t
da945e89-e174-4986-8638-ede57a2b5c50	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
da945e89-e174-4986-8638-ede57a2b5c50	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
da945e89-e174-4986-8638-ede57a2b5c50	2464429d-4856-4d59-976f-40e1e066fa19	t
da945e89-e174-4986-8638-ede57a2b5c50	ddefb625-6062-446d-804c-72b962e7f330	f
da945e89-e174-4986-8638-ede57a2b5c50	77e2ccf9-8143-4935-9800-9986feb17b01	f
da945e89-e174-4986-8638-ede57a2b5c50	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
da945e89-e174-4986-8638-ede57a2b5c50	21862a5a-767c-4bc6-9863-935998fb4070	f
da945e89-e174-4986-8638-ede57a2b5c50	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	364149a4-5707-4969-a163-224dc227ec55	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	a7ece06c-6983-4c98-8f8d-a4559293c529	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	2464429d-4856-4d59-976f-40e1e066fa19	t
7202d349-c06e-4082-a8dd-ca723ae82dfd	ddefb625-6062-446d-804c-72b962e7f330	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	77e2ccf9-8143-4935-9800-9986feb17b01	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	21862a5a-767c-4bc6-9863-935998fb4070	f
7202d349-c06e-4082-a8dd-ca723ae82dfd	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
d022457d-23f0-43de-a367-5764a1002542	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
d022457d-23f0-43de-a367-5764a1002542	364149a4-5707-4969-a163-224dc227ec55	t
d022457d-23f0-43de-a367-5764a1002542	a7ece06c-6983-4c98-8f8d-a4559293c529	t
d022457d-23f0-43de-a367-5764a1002542	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
d022457d-23f0-43de-a367-5764a1002542	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
d022457d-23f0-43de-a367-5764a1002542	2464429d-4856-4d59-976f-40e1e066fa19	t
d022457d-23f0-43de-a367-5764a1002542	ddefb625-6062-446d-804c-72b962e7f330	f
d022457d-23f0-43de-a367-5764a1002542	77e2ccf9-8143-4935-9800-9986feb17b01	f
d022457d-23f0-43de-a367-5764a1002542	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
d022457d-23f0-43de-a367-5764a1002542	21862a5a-767c-4bc6-9863-935998fb4070	f
d022457d-23f0-43de-a367-5764a1002542	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
425e27a1-0201-4864-a8da-1389309f3991	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
425e27a1-0201-4864-a8da-1389309f3991	364149a4-5707-4969-a163-224dc227ec55	t
425e27a1-0201-4864-a8da-1389309f3991	a7ece06c-6983-4c98-8f8d-a4559293c529	t
425e27a1-0201-4864-a8da-1389309f3991	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
425e27a1-0201-4864-a8da-1389309f3991	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
425e27a1-0201-4864-a8da-1389309f3991	2464429d-4856-4d59-976f-40e1e066fa19	t
425e27a1-0201-4864-a8da-1389309f3991	ddefb625-6062-446d-804c-72b962e7f330	f
425e27a1-0201-4864-a8da-1389309f3991	77e2ccf9-8143-4935-9800-9986feb17b01	f
425e27a1-0201-4864-a8da-1389309f3991	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
425e27a1-0201-4864-a8da-1389309f3991	21862a5a-767c-4bc6-9863-935998fb4070	f
425e27a1-0201-4864-a8da-1389309f3991	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	364149a4-5707-4969-a163-224dc227ec55	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	a7ece06c-6983-4c98-8f8d-a4559293c529	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	2464429d-4856-4d59-976f-40e1e066fa19	t
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	ddefb625-6062-446d-804c-72b962e7f330	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	77e2ccf9-8143-4935-9800-9986feb17b01	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	21862a5a-767c-4bc6-9863-935998fb4070	f
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
b658886f-d909-4c90-b9d9-567d24212b2c	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
b658886f-d909-4c90-b9d9-567d24212b2c	364149a4-5707-4969-a163-224dc227ec55	t
b658886f-d909-4c90-b9d9-567d24212b2c	a7ece06c-6983-4c98-8f8d-a4559293c529	t
b658886f-d909-4c90-b9d9-567d24212b2c	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
b658886f-d909-4c90-b9d9-567d24212b2c	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
b658886f-d909-4c90-b9d9-567d24212b2c	2464429d-4856-4d59-976f-40e1e066fa19	t
b658886f-d909-4c90-b9d9-567d24212b2c	ddefb625-6062-446d-804c-72b962e7f330	f
b658886f-d909-4c90-b9d9-567d24212b2c	77e2ccf9-8143-4935-9800-9986feb17b01	f
b658886f-d909-4c90-b9d9-567d24212b2c	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
b658886f-d909-4c90-b9d9-567d24212b2c	21862a5a-767c-4bc6-9863-935998fb4070	f
b658886f-d909-4c90-b9d9-567d24212b2c	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
2d130128-6b0f-4a1c-935a-f8761a4ab63f	a4199a7d-c4a8-4f13-9e7b-eac0de4f9be7
21862a5a-767c-4bc6-9863-935998fb4070	cbb2daa4-50ec-4a56-a34f-d47b547a78c8
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
63d457fb-2866-4e2a-bad6-c9f4e7b96e9c	Trusted Hosts	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
9b0d0543-ddfd-4978-a378-e346fbf97246	Consent Required	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
eb6badb7-b6b0-406d-a29b-0ae74222d7cc	Full Scope Disabled	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
3516d84c-d7b5-4da0-b4b3-26b7b6c05560	Max Clients Limit	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
112c7a3c-9706-446f-a32b-da103be6ae86	Allowed Protocol Mapper Types	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
8008296b-a3bf-45a8-b298-ae45ddbdec36	Allowed Client Scopes	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	anonymous
ef693645-7c78-4dd4-82eb-d5289f8fadff	Allowed Protocol Mapper Types	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	authenticated
26a2a5cc-b905-4b24-a77a-0e6f775ec306	Allowed Client Scopes	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	authenticated
caa60846-91d4-4f02-b1d0-3ff7e9721422	rsa-generated	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	rsa-generated	org.keycloak.keys.KeyProvider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N
4494bfad-23dd-4195-bcca-1532903099a2	rsa-enc-generated	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	rsa-enc-generated	org.keycloak.keys.KeyProvider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N
4da7509c-a6de-4d02-9680-4df4e868b1f0	hmac-generated-hs512	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	hmac-generated	org.keycloak.keys.KeyProvider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N
8cab61c0-19ce-4ee1-ac0d-be7906a8944a	aes-generated	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	aes-generated	org.keycloak.keys.KeyProvider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N
01789b4a-b76f-466b-9e85-b98af953f160	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N
87d5fd8e-02d1-4217-92bd-fdbd1b96f1ff	rsa-generated	b8bb26cb-496e-4ae0-94bc-8c9268be7494	rsa-generated	org.keycloak.keys.KeyProvider	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N
525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	rsa-enc-generated	b8bb26cb-496e-4ae0-94bc-8c9268be7494	rsa-enc-generated	org.keycloak.keys.KeyProvider	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N
30db0ea7-80fb-4489-8ce5-93066ec4ba75	hmac-generated-hs512	b8bb26cb-496e-4ae0-94bc-8c9268be7494	hmac-generated	org.keycloak.keys.KeyProvider	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N
a633ed6f-03ba-4c72-8f9d-23abe7485506	aes-generated	b8bb26cb-496e-4ae0-94bc-8c9268be7494	aes-generated	org.keycloak.keys.KeyProvider	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N
a475d071-be01-4965-a80f-21dc846291a6	Trusted Hosts	b8bb26cb-496e-4ae0-94bc-8c9268be7494	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
f31c468f-2b99-44dd-8e7a-f9fe1e810e50	Consent Required	b8bb26cb-496e-4ae0-94bc-8c9268be7494	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
503d169b-bca5-4e52-9394-148ebd0fd9ca	Full Scope Disabled	b8bb26cb-496e-4ae0-94bc-8c9268be7494	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
8b848063-f9b0-4e7d-99be-9a2c4e6a5aef	Max Clients Limit	b8bb26cb-496e-4ae0-94bc-8c9268be7494	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
f0695312-63d3-4bdc-926c-937d6bb67ba7	Allowed Protocol Mapper Types	b8bb26cb-496e-4ae0-94bc-8c9268be7494	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
fceb800b-f90f-41d4-a8e0-b6890266bc4a	Allowed Client Scopes	b8bb26cb-496e-4ae0-94bc-8c9268be7494	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	anonymous
ed6abe96-bde7-4dd7-b405-c5611f4e16a0	Allowed Protocol Mapper Types	b8bb26cb-496e-4ae0-94bc-8c9268be7494	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	authenticated
84161f40-17e1-4c00-ac6a-36e090c8ee0c	Allowed Client Scopes	b8bb26cb-496e-4ae0-94bc-8c9268be7494	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
3da16e03-0d8b-48ff-bf99-1b86c7280972	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
6fc74c5d-f16f-4b2f-8bf0-c76ecc233428	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	saml-user-attribute-mapper
35ca8f8e-8b25-4a4d-90bb-b3fddd8454c9	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	saml-role-list-mapper
4e60deba-e7c3-420d-b84b-aa382fa03e0f	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	oidc-address-mapper
dc54057d-400e-45ae-b5b0-63760814d884	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
d67793ca-d4da-45a0-8166-baf90e297e77	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
c25b4830-3ca5-45db-84b9-add6dd118dd7	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	saml-user-property-mapper
8dd203ce-99e5-44b8-97df-ceea2ebbeb63	112c7a3c-9706-446f-a32b-da103be6ae86	allowed-protocol-mapper-types	oidc-full-name-mapper
db3693ab-4c59-42bd-93b9-f9414fd5b6c0	63d457fb-2866-4e2a-bad6-c9f4e7b96e9c	host-sending-registration-request-must-match	true
518ae217-5209-4a06-8297-63b726213fce	63d457fb-2866-4e2a-bad6-c9f4e7b96e9c	client-uris-must-match	true
2c92f37a-742c-437c-9a24-6c2f8b7be4bb	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
851d5244-bfde-4aba-9895-6f26cbc180c2	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	saml-role-list-mapper
016d934d-25ba-42f6-9734-9a3d2c066f5e	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	saml-user-attribute-mapper
8b219c82-7c01-4847-acab-9be27b7a6c7d	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	oidc-full-name-mapper
c0f9d840-df84-4cf3-8a73-1f276330ff97	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	oidc-address-mapper
7b206c66-f693-46cd-bba4-9620b38a0fd4	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
ddd46297-a212-461d-b2f1-3b304edf3ba5	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	saml-user-property-mapper
f94b956a-b2a3-444e-89c1-3b578a6ff518	ef693645-7c78-4dd4-82eb-d5289f8fadff	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
3df1cbd2-bace-4147-8fcc-41ee4b6c1d62	3516d84c-d7b5-4da0-b4b3-26b7b6c05560	max-clients	200
8a3aafb4-aade-407c-b028-1f406ebeeb75	26a2a5cc-b905-4b24-a77a-0e6f775ec306	allow-default-scopes	true
2ddd9fd9-478e-4840-9d66-1d6a71ea5945	8008296b-a3bf-45a8-b298-ae45ddbdec36	allow-default-scopes	true
fd9ed41a-cf76-4fbe-a3d5-e989312792b3	8cab61c0-19ce-4ee1-ac0d-be7906a8944a	secret	WgdCHZCWZvqUmJcJkS2sGA
ed2ba8e4-0549-4fe5-8a79-17f9d999af25	8cab61c0-19ce-4ee1-ac0d-be7906a8944a	priority	100
b0f0ac65-f042-4da8-8140-da315efb036c	8cab61c0-19ce-4ee1-ac0d-be7906a8944a	kid	08a7bef9-6249-4577-a7d1-e0d07f200817
5ca50357-8859-42f5-a4af-81bf39f7601e	4da7509c-a6de-4d02-9680-4df4e868b1f0	kid	c4b12cd7-4680-46c0-8d81-e2eac17ece72
8102eff5-c598-4b36-bd57-f1a4c6595b3d	4da7509c-a6de-4d02-9680-4df4e868b1f0	algorithm	HS512
1661a911-27a8-4706-96a2-2ed5ec1cbe9f	4da7509c-a6de-4d02-9680-4df4e868b1f0	secret	KfQwbjrN6eeQoja4s4XCTOTjN8MpY0Fgdn_0MbAO6xHOQVfKmnSJxri9On_2DK38EDacqZt1alG2yXXNOh1xOOzz5s-qDkLD8LsP0OWq_ySdBCevVViDqYD1QvtFOi9h1xhv0TsRP3lk5Hu3jKkiCi5s_u5DqipdPEXIX4SdVGo
bba4bdeb-1ee8-4f35-8ecf-eb19e3fb1f58	4da7509c-a6de-4d02-9680-4df4e868b1f0	priority	100
1b91ea12-214f-4a97-abd7-16b269df569c	01789b4a-b76f-466b-9e85-b98af953f160	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
2f449ba7-626b-4969-b067-73071a1d8ee1	caa60846-91d4-4f02-b1d0-3ff7e9721422	privateKey	MIIEowIBAAKCAQEAzN9PQ8mKAz9GPDYI5Pa3qlSFq6TKyPjd4ytTPBc1WSjLuUkfLHprYgCDYITbxfdmPB9Xk1I7hOo9a5QEyPPXsgoJQhY2DWoeZHDPA8EhBavR+3iLcXaHtH6Pu4W9ar0Dw69TsyI4ppL1D4OYsbMDkCNGqQ7OnByL3g2eFp+0or9t6FesO5Vsi1PmPC/KDDz5vY1jYblFH/3vB7y35UoqrFsA47mAQiWhjQDkBLXPQ4VCq3jk7vumYJsFInhUUHpFVng3DGKVWvHEU/f78XytWs0lgZ02RtbxTJDM8TTvHMK87l6SABtu+Q6PRtMXkAbRcxyZeZm4rTYWsGU7tCqLLwIDAQABAoIBAAMTENX0FtGgp/WsW+rPtwbj2NOwF+j3LyFDG68pq//ICHKh4clhlu30EwSmScQJR+v8DmzkDYebmktcf8viOOjvlJ78xVfjMUyRktG8GrpCj1amQvVzcWrogVCvm52X85ACuA9WoqIBT5MphueXx6Romx1bXwdhuEmfS7GMOQI+NUqxmuVTFs9Xg4VdlqfhaezQUpgGPvJGIQDFy8x1rdwDtndnzfObN8Q+vJ0kOPF8ko6op1CDtMijg+pZz0lQqR7W0u9A7n6q5kRJW/6YsmER7NX4Pmwf4UC89yCKlXUtzQstnQ4+Rid+tod/yAyCAMi/LlFwpg+JEUXOIk4S7x0CgYEA+QxxlZ6lttlhZKhLLwpmlmk9oOCAQe19iPc4iDnGtJdxyAxQycfESPuHFMJ3o84W+6fRT8qDH799JvZQWQ1zZX9LRFw6qn01hn/Ugn0LFtg8qBLh72/crW1bMi189DIOJuUlCBMY/wciuEWyv/cV/IZf5022o7R4v/b0PwFIziUCgYEA0pc1MdUIqb1Q5hU7JeHu6AU/YqA9UKE8x7NiEatjn0m7akRFnDYjjxwU+2kRxHUqlt1WHgOJwgRXYQFowlrbjVO9uxhPBvPB/C+Zcer1TbAqvTtuxzMLFgd/kDiJQeivlSFkKpCmMH5BNdOfvnf/+6TGT1uo5+SIjIInKjI74cMCgYEAqlz/ygjHdUhInlGddKVZveRp+wX31qF98VakPlO/gMPkWqNKFG3p8L7XDbVloBEXmbiXr0xp3CrikueF2RUhbjngo/evTfbuyX3iQg0Fq+/ptlOMaH0N6TjYXH/PbUBce/DeHyLpQ3N/JazP9Q8x5BeLvS9lE6EdxLtLI1pekl0CgYBIJ6UDUQHp3sL0QrwEa9hGyV2BdnPrx4MizZTBhx7YOhQsAf5z2pzucOnDhqmezaJtFKNoH0A5KPGjfC8fwK/PSa0NiPOy5xxFQy3pOV8ZYk4SjmWTfSrEPod3q9djrM1UZJ+EchFvNiMzxTHLuiQMXdXQ5RAHfGdI9WNj8thPrwKBgFWkrbYd7fA+kTUkCvK7lg9a+rmudhHudgnQik95Z+X7p3lEX38WM7hMxKXWMoAd1Ox5aR2AIQ2dM8Yuepp0uIn2M3jkRGOtw9lPYd+4OaxOgQCULxpGFJ4ivvb274+3M9UKDLw8yrPrF57hH5phmo3b11blh4QndxFotPMqYKwQ
e4ec116d-f07c-4ca2-995d-463d47cb3322	caa60846-91d4-4f02-b1d0-3ff7e9721422	keyUse	SIG
8c2bfe1a-1c94-40a5-9912-2ece0245401b	caa60846-91d4-4f02-b1d0-3ff7e9721422	certificate	MIICmzCCAYMCBgGXxqY62zANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUwNzAxMTUzOTMyWhcNMzUwNzAxMTU0MTEyWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDM309DyYoDP0Y8Ngjk9reqVIWrpMrI+N3jK1M8FzVZKMu5SR8semtiAINghNvF92Y8H1eTUjuE6j1rlATI89eyCglCFjYNah5kcM8DwSEFq9H7eItxdoe0fo+7hb1qvQPDr1OzIjimkvUPg5ixswOQI0apDs6cHIveDZ4Wn7Siv23oV6w7lWyLU+Y8L8oMPPm9jWNhuUUf/e8HvLflSiqsWwDjuYBCJaGNAOQEtc9DhUKreOTu+6ZgmwUieFRQekVWeDcMYpVa8cRT9/vxfK1azSWBnTZG1vFMkMzxNO8cwrzuXpIAG275Do9G0xeQBtFzHJl5mbitNhawZTu0KosvAgMBAAEwDQYJKoZIhvcNAQELBQADggEBALVPLXaB5lZceUzCkuXhX13dWHzO5ZAJx8NFutqjaI/7/iqohDRGnrbIt+mcLfX2Sk1BgjBAOLvtjLB0nO5zJb1UjvTe8dxkbWpgogu62jh5y3fuhHGC6iIgQSXx1c4QAfDhvDu4+Ya15gSDFCjobKbEIc2zRGwMQFgXEDz2qkRk9P3LRbXWfC0PiqUTm6PHFfyRo5iwhFZPDoBX3f7yO0GUFQKb3nZGdn9tbimd14mlfD3+73byJtNSupynZUQ/urOc4djo2qu7Aiq7VEPYNASSLqKU/TP9k2JwnPXLk9qlBI1O7g2f6RpccxQJxyvUdGrIQGriwVSE9VHfWO1dlrI=
8b04fde2-d061-4c11-a112-ad47344a67cf	caa60846-91d4-4f02-b1d0-3ff7e9721422	priority	100
fe58635a-be3e-4cac-a6aa-3c37fa69a338	4494bfad-23dd-4195-bcca-1532903099a2	keyUse	ENC
f1a904c6-b901-4486-9dd2-343019f69a51	4494bfad-23dd-4195-bcca-1532903099a2	certificate	MIICmzCCAYMCBgGXxqY7wzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjUwNzAxMTUzOTMyWhcNMzUwNzAxMTU0MTEyWjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQClXjEHwntwdOggmEbDVkSuVVFQHoPcqVdxkdZnnTvn6Iq/t9uM5Rcj183Zu44QJiGpXnhDJKe3gP3tdBxTPVl+dzAhm3oCp2L7T1I/B+AkwEqWDUi0xObmRC3YDCxoHfxjDolAXDcRM0w3lpAZrL8lkr0hQ6rYVUD3qOTJF5fOOc+2/BLegfbj18veyv74ADYPnxZz8AWXg5RLm6Z0gNwWnIDuWhrYBKhXKaxfyQw/8tJ9rtP7/UTU6LtDo/qVlOYeV8p3XLl2kw2NAjmDHf8PyAZkI8f6S2b+IxQ+JOpefUW90Pe7J4I6S7kuLslR27N4Tn47OoV2aIrRRdah3k+xAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAI3ZPrbGEgz3C52RLO5VIVNogUiFAMKaoYahGikn8rmOA6VWRqyJWik9TF7QbhJ6H2e8ghjVyJfau+i74In+Gu5vTiSNiFrvZAf+lOHYLff2tlCBn3kJO0HMRpCCnJsPKT96lQZKz4fcGcHgOH9CLtp1zPTVBPwEYkgdbfD3jgotsaToMr/KbrySm+ZOPVF2G4WNuTNdEwwm0ezW4a+whNGU5E8fIw9oQk7Zk+CPHft7Q2DhxG9txyC6CCFQYrdzx7MGxwa4KZPz9v9N5NAifp2YT8/KsSB68efZhvz6G6OSOcPYJDy11Pi5VVwfMm66lJN3ITVHHtKs6MmR7/OaItE=
364d0dba-9e02-4b2e-b3ea-4c95f8352ac9	4494bfad-23dd-4195-bcca-1532903099a2	algorithm	RSA-OAEP
79a7f7c1-e739-40e0-99fa-caa95b6089e9	4494bfad-23dd-4195-bcca-1532903099a2	priority	100
b5c9de10-e250-436e-a172-2868488dc4cf	4494bfad-23dd-4195-bcca-1532903099a2	privateKey	MIIEpQIBAAKCAQEApV4xB8J7cHToIJhGw1ZErlVRUB6D3KlXcZHWZ5075+iKv7fbjOUXI9fN2buOECYhqV54QySnt4D97XQcUz1ZfncwIZt6Aqdi+09SPwfgJMBKlg1ItMTm5kQt2AwsaB38Yw6JQFw3ETNMN5aQGay/JZK9IUOq2FVA96jkyReXzjnPtvwS3oH249fL3sr++AA2D58Wc/AFl4OUS5umdIDcFpyA7loa2ASoVymsX8kMP/LSfa7T+/1E1Oi7Q6P6lZTmHlfKd1y5dpMNjQI5gx3/D8gGZCPH+ktm/iMUPiTqXn1FvdD3uyeCOku5Li7JUduzeE5+OzqFdmiK0UXWod5PsQIDAQABAoIBABPMWl3ltp4g3P60BHrT+/6MN+M5+AsF2jJ+ZZc7n6W09VGdO0Ob1OClcF+CQTClRA/xP8A4Jf1GDACvD0oW9P07W0+Wu+2P6T2RwlTKBleYDwX2eq8ryMImRP/R+0oO1v3sCloigDRGujgIhmGQiUUAE7UlExH56QCNn7CEqtfVafW0eRSEx5Yf1EAF17u1Gud6UsYAEH8Vyhrq7XE56oXVqtm82OlJFPGwoIn9Xh0LORGj4AXyptX5qUO/e02LwGkAyRNFglhFSRWMOSbGKiPDzkeX+pFNtO0JjCWTLwU1aOSWpH5+K/FiJ7KTPEPS9fVFM0YrGWFDCdcpTxXdGX0CgYEA5sLEyl/lS05Utg6SylhGZScX3N5OppM4WS4db8/n30ppQoFgtjPpCb2CQ07O/L2TE37vngpPW6w2/Sd8HKbMdPqrhc7+sDOHNJQD4kEZxd2G5FQN/KoHMVEFuOfu0Xjp3soJJSQZYhUUGgBffJzJiNdhIIqy1olDif215HMJnS0CgYEAt3RxRLn3FaQybVUES7S37Z4OxiOxnpodue4HGtTfuysW+YEOztRhPPihBCWkE6fiVx+J91jAKh2C8H9NIi3yeaWOCWOHl1GxCwUSYjh8u/fDmVnBua+Ld8M0PRh8iTPd3r4Xcjzq4/Rvx0lRCcVedKbgYQN/IBLGPA/9qanm9xUCgYEA0Zh6se4kECBXpPzbq1o+pkW50O1Ctt3lQms2ZYaLby7hKHzm4NeJhUVR+dys+LcfzYdwETYAGp3zXEDu4/9EmcPM4z696kEDP2hplqnWxPePO/h0s9ejrNGQxwAy1KRkl+0eHVQKkiHfHjbUhBTMoLQwDiSsh1wpsj51ZchvJQkCgYEAkzF7XCA1joii6TQocTG7zYxe4D1tWwrexPqlerLIHB2znlcdcXfX2RrH3lLxNdAi+7JTeUEdVe09zQbm9YCWJ2Jc902DUjb6bRQRrvsRoaNmrhjlJb4ikeHufQKzkUYrQ3eTylX0RRgvw18hBUz1v3TRXSV4D1zg7voJleK7bQ0CgYEAuB+ZnMRbMDsU+jxOqyebkKnLFBuW2NZjRCHNDsdqJbi18MtykFBYL4Av7NDJvsjiEWKLDyLJF6iLgk5U6n5yJNWnYHtOlA+XCQI1DAkSZerH5i9Sp/Q+XbFNsYGBf+FcSYd13AMhhEsuHDDnyZfm4TF1hRBc3/Ig5h9+hjkYsvM=
7539acbd-a48d-4b07-9865-f5b500d4815c	87d5fd8e-02d1-4217-92bd-fdbd1b96f1ff	priority	100
ecd36479-1caa-40d2-89ef-0c0288bc3057	87d5fd8e-02d1-4217-92bd-fdbd1b96f1ff	privateKey	MIIEowIBAAKCAQEAhthGuOevF9FF/osyoAINkg0yThp67ar7n6VWhWUzbsGhPuTFRrB+VFSnCtcssZT2CkVa6lI24daIRXlxeMTdzvb5t5rlYwSLCryuJNc9OT2uREycIZPGFCWxkLoCQGh4vXAQvTZZGTIvJkEUwhHzCESEU+ef5m9v0tjgO9OEeXhQ9Suv31W1oBr1OrMcZl2slL9/azUeqhZDczVUqOlCxe3tFLapiozK/A8g1unwDuvAA5QxVy97WyoJI8zrIEsHY8wZDCCi7NPDx9u3By3Uhzc6nyDsjS0wqFLqMxT/M14WjYcoDB8ObQqaXh/wJLKGIxeNRf+uuo/nBlDm/R6j8wIDAQABAoIBACwWf30KRy223zc75Mf7E9vKU8XEk6esbUvDv7eqoHfYeDN7keKsZwmEif8Z3kOLjCxMg860JbyOK4zniYmueEUoa/oze0d2H03Z5egmtZ5HA/jRwYSa77r7ngRPRNgxMDTj9J0grV33EgJkafiP7NGpsUhLpXSuv7WE8j+tRxV9nx8ZfOmgOSXQYh8b2yn0csAz+iGI6igiImUuobCSHQobCNKXIyq73KOQiX4QU244y+uCTN0jF+lutIwXA0h72fQFrxhHpyZ+7OIWnDU/dPndZAfrAZWYibXXAHTNZi+0dalcv7RoI0JQVmLcuX+/Y5hk/BJmnaqaMEc5erP/sl0CgYEAuyB+1iMJR10Nxr7pHkouMwNb7MS7uHARt0wM7S5ug0kGDHoJAuRz6k0OsSSPbFMFAoXbmdXeyRPN9Umh9wXcfFbxpoolTdXaIdDOVeZPuiW9MDTXvyWy+q+5LWWITRnJapf4Yt6LVnlIL2BWMbnNOlLuvjgyNL2QZ8pIQ18BRk8CgYEAuHmlzrZ8DiI/+eRMSUXI09by/WMSu/QifjHcvNz1CGxgN4+V9Ntt7ogHEoTOil7AdBhsbfWTFjYZt3p5t6ZvKMFvP8Mdg6ucMc9YefNVqBnxroyJyDvKbtwFKGV3fUw5NH6ivUFQ135Yt9VyYZBSY3QQHsR2TXC3CczHGnB9Qx0CgYAUmRkdHTIyRs3zaKRkjynSt7XwtB8tyDhLAvYRTaEglnMyAGTpipgv3FeXrDyVYfYVNwLbRi2F2MY9D+PiOyTwEun6uQ4uKTIfsspjrjxscycGHWr6QX4YFiu+EYUVZ5dCQoQ27eRMmoEVpfcW9irfFq3tBmaQY6V3p06ZC+YqBQKBgQCTK5l3/GWj8PcRKW0i16WMO2PHeo6rm+0YuDbeBXkGq09nhAmiOpzNO4BI6eLMySLIe+OlJdGeWrLRicgpF4J/BTL3r3WQYgxOQJjZUaP4ZBpHop8ZO3oYTzdeLvTQ5UqN8qlqSv1vrcChiIukAjt4VFO3+AxZY57jFpeRJEUKkQKBgFa86JMkHqKKrllaOgF7PQu9eS5diM3WZWfDYZznSuNkZQCZotY8oe51EGzpUJGTs12RokJbA8Vw7DkhaF48XNJmw3SIzdJKAqiKCyfXqcoxRssWX33FcFa5zerrGBVVhiggAlp29l0MJ7N+phE1goTLYWUxFYkdPr0AoeWFQ0Cq
446b5283-a1a1-4bc7-937d-f8d1fe4b4d7c	87d5fd8e-02d1-4217-92bd-fdbd1b96f1ff	keyUse	SIG
49b80342-e09c-4cdc-8f41-37a2eb4f7971	87d5fd8e-02d1-4217-92bd-fdbd1b96f1ff	certificate	MIICrzCCAZcCBgGXxqZCyjANBgkqhkiG9w0BAQsFADAbMRkwFwYDVQQDDBBuZXh0anMtZGFzaGJvYXJkMB4XDTI1MDcwMTE1MzkzNFoXDTM1MDcwMTE1NDExNFowGzEZMBcGA1UEAwwQbmV4dGpzLWRhc2hib2FyZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAIbYRrjnrxfRRf6LMqACDZINMk4aeu2q+5+lVoVlM27BoT7kxUawflRUpwrXLLGU9gpFWupSNuHWiEV5cXjE3c72+bea5WMEiwq8riTXPTk9rkRMnCGTxhQlsZC6AkBoeL1wEL02WRkyLyZBFMIR8whEhFPnn+Zvb9LY4DvThHl4UPUrr99VtaAa9TqzHGZdrJS/f2s1HqoWQ3M1VKjpQsXt7RS2qYqMyvwPINbp8A7rwAOUMVcve1sqCSPM6yBLB2PMGQwgouzTw8fbtwct1Ic3Op8g7I0tMKhS6jMU/zNeFo2HKAwfDm0Kml4f8CSyhiMXjUX/rrqP5wZQ5v0eo/MCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAEdam20z3mQrhdVNOpTrtovXt8t8bgSxKwGgeVIp5qq9+FP1pnIzHUJ2JGb4rJMMPw0tcxH4+hNm/1t65nPKR9m8+iwq4r/9JZ0eKl0Bi/Xu8nX3qMni0CXpdI57D3fMqQuo7BxA0kB7scMkCx/f1GJbbOb4vS/syT4ceCrS65oIeJnLghtgd3JsGyuGdoGAKVMgXQ2ot+uOkXjC0oWP6rCESl5NQXiYc/h+I3lf9nLVKH2nbBHG8NcsQ2unlgkXhq/4Kjv8SrQOTyla70+10Rb1DkC5eVHBXfYhOB9gWu18xZA2RgOPZ+HIWIPqCMI2yUZtwyaAONy6J9sZHNqBq4w==
ed3d7d42-c299-4266-ab1c-72e38cca4388	525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	privateKey	MIIEowIBAAKCAQEAxmMvZw1PD+CM3fPeDSovmL+wd+XxduhgGbyXoKi3tmU72IP2Ln1d1UtOxi21Ops9p3tjjEQ7Bvp8n2Fex7BebKInDoyMuchRthDgL8aive9oYGEgHA0DuIX0tBnKBkoCONOnPS3ZwLDhjRgf49Ed0QKDbVxPfWRsraq/JA0Ut/TM77i5OcPjW/ot2L306yfdPoGf3nleCVU6PLQFnMEs3+nClzfkQaBnG+6b48MwKCFfsSmyDr2PbNBdXFRlfgiduZp+u0Bfk9wR7w6gtEcMOOyYAMu/3z9b4P7QqqMY+4Kqw0DSWX6ng+Z2kCXWHexbV5TAiHsK86RAFO6ZcjHv9QIDAQABAoIBAAfxPxvVUtG8J++X3I8y3epz3C0Eqezcg0JshDaEoqw8888og1Hbp4bLR8lT2aJRxj9fB359Wc6e9x/LXmfIthMLz9v7gQPMEwdiuBL5lRjdDZT0NnyhAcHgrQoL0UR8sIeVY6flnsbh3fnP2jD89YBhZSEa9by7qUUvpYzcMDToGEB02udcP9v5+2NnDRcrQbUyTm04P6+pCQ2RIwTFenZcblIFXiYaL/C23AlGl4aW8wKScMx3DPpLD4+wHKiI6Uc2IfYmPBSsAsVHaGyI72esMIdveg7LUxnW5mDQ5qgvmcu99fq63XjzHFkDu+o6BhXZjcRUpgseXEthSV3QmyECgYEA6i4Tn+vI7eRUN1QOu1Fl0uFiCl6FZi+3bxEtXsZwYpKQGrf7EgkaOF+n4s0vvAfyCTWbkx1mhd0GXQp5t2ChyVHWVHCW/Fg32qmYfnHP0++5o4Z2mayxveEG4eZSBSPuJBjn+K0BzZ9bcpiUsO4BGeskIDfj0uceFKmT32aKD2ECgYEA2N9YOiPv3PrGGeYXBBxSaGCV8vg3NAkQDVAMKxQHcYElY6BVzpbXgNN3/vWuq7LcIAMPiTr4sUabjC/Vhh8BOoAq48tDuKo0PDgZ7zxn28EgyYjk9+w3bJCEzYwpg/EeUkkX3wvBfxjn35XkIro014X9YmSyy3nWKUxRs6tOzRUCgYAS9MHf6x0rrJTomaRLo24joNzny/juaaRmmDRc/KEySXzivMvVDOmTcKLNaCCaDuaXukAqq3GWGmsecu+hWXAfNMGtuiNur9FtoNbYPWw+UqRrSUImdGU64pFFDfjLs7neMCnu5kpEE8c6QoGexNVP/MnC1eNaOh0kPQncRpecYQKBgQDFZr5C5ZUeOnD4//NxPWpRMaErcH2m8pzW0UbSKz//M8NZpIaWLbzouROfUfd0t7Afv0lz6uaVTiSlfKDJnQ0cN69SeyEgRGSZb6NDnGMYpvj2GJH5jNyCCCWphuv++glUcs20q1msG3prjF8EsSMKDh8uYWRRS4wBOUOg28w1ZQKBgFbVT2jaKCsVg0IQkepbL8jdogAS2qtwCteLjV3VhHEhvVooOfRWeDDy/WlBMsG1wbKk7g0ZPCCJYV9yWL14cyI0d5DRSYwVU+sPkxGbausXazzwS+66GubJ8wvWfi3cqUieCuze2F32hKDGRDOmzj57kVUI3HX3aEqEU6Vfd3mg
5fdd03be-c4ca-465f-a11d-103ce60e4657	525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	keyUse	ENC
9ed8222e-4e09-4c92-8c70-f766901c6739	525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	priority	100
96ef572d-ea4a-47b5-9f8d-8b7424c049db	525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	certificate	MIICrzCCAZcCBgGXxqZDezANBgkqhkiG9w0BAQsFADAbMRkwFwYDVQQDDBBuZXh0anMtZGFzaGJvYXJkMB4XDTI1MDcwMTE1MzkzNFoXDTM1MDcwMTE1NDExNFowGzEZMBcGA1UEAwwQbmV4dGpzLWRhc2hib2FyZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMZjL2cNTw/gjN3z3g0qL5i/sHfl8XboYBm8l6Cot7ZlO9iD9i59XdVLTsYttTqbPad7Y4xEOwb6fJ9hXsewXmyiJw6MjLnIUbYQ4C/Gor3vaGBhIBwNA7iF9LQZygZKAjjTpz0t2cCw4Y0YH+PRHdECg21cT31kbK2qvyQNFLf0zO+4uTnD41v6Ldi99Osn3T6Bn955XglVOjy0BZzBLN/pwpc35EGgZxvum+PDMCghX7Epsg69j2zQXVxUZX4InbmafrtAX5PcEe8OoLRHDDjsmADLv98/W+D+0KqjGPuCqsNA0ll+p4PmdpAl1h3sW1eUwIh7CvOkQBTumXIx7/UCAwEAATANBgkqhkiG9w0BAQsFAAOCAQEAHB8/I38zPd5oBAFRGJvLdohhA/WFI3vnqag5E9nEzX951cdaJ14/ighuS+TpT6a5yOx8s9IRjvemhmT/vYOZHyOi1lnmBmyQC70nAGAa5Us6By7jmRFuBdgesRzWqZE0qFg2yiogFO7lpxh8MUGCtouiJBR6wnjLfQc4Xzh41PFNY39+Bv3H4apVFMDM72B4oMASnldv3laLLajPVQSF5lcaDPzCTH18VVIXUdQsnPqk/UvFN0l+QtywSBESHz53WEFDwLC8sLthXoqdfy8TbkwRRkZIH+KQYLbtqqak9fQnopzYzYz+VI4m5Q9MpK5Vd3ZHfBKRP8u9s0jC370XDA==
9013f454-7d71-444a-8bd4-3747197422d9	525aeba4-1ceb-4fb3-ba73-ad6c59ad72b7	algorithm	RSA-OAEP
fa600404-fa08-407f-bf6e-4b5250dabeb5	a633ed6f-03ba-4c72-8f9d-23abe7485506	kid	e6979d19-db0d-4d0d-9ad4-086d400e82c5
644a36c7-e0f3-41ce-93c2-f9783c707022	a633ed6f-03ba-4c72-8f9d-23abe7485506	priority	100
3ecde48b-aca6-4b3b-9d1f-c3dfa1a8821f	a633ed6f-03ba-4c72-8f9d-23abe7485506	secret	MZAfLj_ZkONZvw3E5y5KdQ
09a2d845-2722-4bdb-b3d2-77da1816a946	30db0ea7-80fb-4489-8ce5-93066ec4ba75	secret	pCqQgyGFzsHPmBYw6a0aLqLN0n8gN29Ac0wUdjkUlO-SMa1UyC0i-Q0OG1sEKWfX55m8Rbe3MvS8oM6prhofj_CyPD_PIhAqTtFf9aDOt8LGvkzbvCK-CmfBx_cx_-7rk-qFl7EwoHPu2wqY9yyYaseLCrjVpfAxqq24-EbeJ_o
e777837b-d2c3-48f2-beb4-581dddb2f2c8	30db0ea7-80fb-4489-8ce5-93066ec4ba75	algorithm	HS512
42ca618f-e878-4e96-b5bd-7f33f1bb05a8	30db0ea7-80fb-4489-8ce5-93066ec4ba75	kid	1e88b187-7964-4625-9258-ffca7008c93e
0ae8b0ae-81e2-4c77-9338-e27a062b52cc	30db0ea7-80fb-4489-8ce5-93066ec4ba75	priority	100
29917c95-eae0-4116-b9bb-86806a2db8fa	8b848063-f9b0-4e7d-99be-9a2c4e6a5aef	max-clients	200
ca3e8450-66ad-4e7e-b894-a7aa9369cf8d	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
d0978997-fc3b-465d-a346-03ca710881de	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
b8ba5136-7ec5-4e8d-9f69-d4fcbf11f07a	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	oidc-address-mapper
593338cd-9be4-4d9d-8672-5eff8e572a16	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
9a8bd186-8126-43d0-a1eb-b41ed5b618bb	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	saml-user-property-mapper
06a9f27e-d686-45dd-b1ce-646d4f2fb1b6	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	saml-user-attribute-mapper
794206e8-3b07-4f7f-8a61-d1a292e8ff2d	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	oidc-full-name-mapper
749af211-baa2-45a9-8c21-8e2dc383e290	ed6abe96-bde7-4dd7-b405-c5611f4e16a0	allowed-protocol-mapper-types	saml-role-list-mapper
ade855ea-8b60-4ef5-89d7-4415642fa798	a475d071-be01-4965-a80f-21dc846291a6	host-sending-registration-request-must-match	true
d4d6a1dc-c67c-4f05-b789-35477d25047b	a475d071-be01-4965-a80f-21dc846291a6	client-uris-must-match	true
0ae63e53-4f26-49f6-823d-ef14fff37132	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	saml-user-attribute-mapper
133ca8ce-b4a1-4a8d-8d01-c8142eaacc6a	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	oidc-address-mapper
f2126aef-9a35-41d0-9d93-5267300238fd	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	saml-role-list-mapper
b476d5c7-1fca-4ea0-909c-0cdd957bfa51	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	oidc-full-name-mapper
eb6ff83b-171a-441b-872b-ec97c3080c1e	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
e44b12d8-4369-4eb9-88b7-9a7377eb0f84	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
c5c3ac52-436c-4d19-8c60-c05c49c42be7	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
12e9a470-f4cc-4624-af86-7966d9d9f831	f0695312-63d3-4bdc-926c-937d6bb67ba7	allowed-protocol-mapper-types	saml-user-property-mapper
5a868c6a-959d-4b8c-93d4-9c527d33b1fe	84161f40-17e1-4c00-ac6a-36e090c8ee0c	allow-default-scopes	true
f2d76603-15ff-4a7b-9f5a-a0181d8bc4e2	fceb800b-f90f-41d4-a8e0-b6890266bc4a	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.composite_role (composite, child_role) FROM stdin;
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	3ca7820f-59a9-45ae-bd95-f75a1855a6d9
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	76bafc5f-bb0c-4655-bf77-2d1dad29a0df
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	abc6ad36-4e27-4738-af9d-690ee9d0de74
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	7aaea338-a2bd-49d9-b1dd-37bbc908a3f1
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	821984f5-644d-42cc-9621-3952dfcde2a2
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	26e3c81f-4ce6-466c-ba00-110c23709240
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	414617f5-9e45-4fdc-aca8-863fc82782f0
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	0e7f57df-e111-4af8-9494-b31e0288c39b
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	126133e0-2aec-4486-844c-86e335e9e2e1
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	c49c1c0d-3873-4a37-9e79-3340f606d078
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	7d4e1ed1-78fe-409a-80fa-097a0136f27e
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	1b143649-25e9-41c4-9668-6ae4e756e1ec
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	6532f036-08af-4d0e-be1a-0394ae886cc9
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	99c37b35-6acd-4b22-9f3e-06564ffbce29
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	3f042a23-09f1-48f1-aee1-3197c4cdb4dc
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	f93756b5-a87f-48e9-a1f4-3b4506337128
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	c19bb22e-704d-4926-b6a2-dace7cfe2a6f
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	74445586-64e7-45a2-804c-75d87be746f0
6dd805e3-8294-4275-8426-5a6940872806	07be1f47-7098-4bec-be9e-ad4b12628c13
7aaea338-a2bd-49d9-b1dd-37bbc908a3f1	74445586-64e7-45a2-804c-75d87be746f0
7aaea338-a2bd-49d9-b1dd-37bbc908a3f1	3f042a23-09f1-48f1-aee1-3197c4cdb4dc
821984f5-644d-42cc-9621-3952dfcde2a2	f93756b5-a87f-48e9-a1f4-3b4506337128
6dd805e3-8294-4275-8426-5a6940872806	8c9da990-75a7-4fc1-9297-0c9ca92ff2c0
8c9da990-75a7-4fc1-9297-0c9ca92ff2c0	5f64800b-6cc9-46db-9a93-04aa5fa96ec9
06a9bc3f-3114-48da-8b9e-34430d2d8468	bc08fff4-eb3b-453c-8d5c-0f0ee4515e27
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	36aa9915-617c-46a7-8fe8-c3ae21013027
6dd805e3-8294-4275-8426-5a6940872806	a4199a7d-c4a8-4f13-9e7b-eac0de4f9be7
6dd805e3-8294-4275-8426-5a6940872806	5ca207fa-947e-48a9-b48e-6c4d5b17cbe1
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	8b12a05c-866e-43d4-8b8f-6fbbc57d459f
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	4db61c65-95a8-4f7b-89ad-4a1936a68371
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	d01dfa0f-40a0-4f1f-afb0-a5641ba4ca67
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	0a8ae95b-b6ca-4d80-aec4-f8c8a1b0673a
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	e2ee9e8f-9294-4d7b-bc9c-8186acb95cb0
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	4c7b4cf8-7182-4a45-9a32-0d38da165a26
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	ae61f5fb-493b-4a0e-8417-bff9f9197d79
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	9defc2b8-4446-49a8-b7da-5456d3a4cd44
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	e2b804ef-82e8-4a51-85a3-0b2069cf8481
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	b461aaf2-a3f4-4995-a85a-2c0de29a80d4
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	f5d3c9d8-fcc8-44ac-a1ad-24cc4ed0a1f5
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	981ca916-157d-407e-829d-50d446eb705c
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	dc05abae-c052-40f5-9321-143d8dc05f8a
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	cdd43fdd-751e-45ce-9c7f-42574ce567f6
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	34975fd1-7393-4c01-aa02-f4ddb7929016
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	0ea82cc4-0667-4991-b120-397a595680dc
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	c17a655d-e93a-40f9-b80f-d09f425c0f67
0a8ae95b-b6ca-4d80-aec4-f8c8a1b0673a	34975fd1-7393-4c01-aa02-f4ddb7929016
d01dfa0f-40a0-4f1f-afb0-a5641ba4ca67	c17a655d-e93a-40f9-b80f-d09f425c0f67
d01dfa0f-40a0-4f1f-afb0-a5641ba4ca67	cdd43fdd-751e-45ce-9c7f-42574ce567f6
55f5d9d4-4544-4b29-a949-9c339a088af6	651bf7b7-f483-4cf4-8ff3-1c288a81418a
55f5d9d4-4544-4b29-a949-9c339a088af6	b0b4e6fb-db39-4edf-a8ad-cc8cfabe180e
55f5d9d4-4544-4b29-a949-9c339a088af6	3293e9fd-37dd-4f0e-9b8c-75c31ee07d2f
55f5d9d4-4544-4b29-a949-9c339a088af6	23d770d4-a237-44e3-8e8a-1115e200c5cd
55f5d9d4-4544-4b29-a949-9c339a088af6	02e38170-4541-4277-a557-ef53a5b46932
55f5d9d4-4544-4b29-a949-9c339a088af6	151aaa5c-8496-434b-8f2a-98d2b5674cb2
55f5d9d4-4544-4b29-a949-9c339a088af6	fb642436-9506-4c94-baf5-d94a11e7bd93
55f5d9d4-4544-4b29-a949-9c339a088af6	6a784e1c-3936-4d81-a559-c4c0c0521478
55f5d9d4-4544-4b29-a949-9c339a088af6	623e49d5-946a-4be3-bebb-94d6d5a65919
55f5d9d4-4544-4b29-a949-9c339a088af6	cd21218f-9a40-4b58-951b-1e871a3995e1
55f5d9d4-4544-4b29-a949-9c339a088af6	0f3935d9-5f93-4426-9c9f-8edacdb49539
55f5d9d4-4544-4b29-a949-9c339a088af6	fb945b21-4cba-46cb-b3b3-be386c0c1e90
55f5d9d4-4544-4b29-a949-9c339a088af6	6fcbf27d-510c-4b47-8b17-b6c77037e53d
55f5d9d4-4544-4b29-a949-9c339a088af6	4261522f-b425-4556-9227-b52d122ada68
55f5d9d4-4544-4b29-a949-9c339a088af6	d7e9f0f0-1982-47fd-9ec8-b3fefde92ff0
55f5d9d4-4544-4b29-a949-9c339a088af6	8930d296-b2ee-41ff-bd0a-390a2e2d29eb
55f5d9d4-4544-4b29-a949-9c339a088af6	9ad8e669-96b2-4a80-9b62-01c2e0ce83b7
21a7ccab-f27c-4bd6-8f34-2ca60d790608	f709646e-93c8-4cdc-b344-ef093ff83d71
23d770d4-a237-44e3-8e8a-1115e200c5cd	d7e9f0f0-1982-47fd-9ec8-b3fefde92ff0
3293e9fd-37dd-4f0e-9b8c-75c31ee07d2f	4261522f-b425-4556-9227-b52d122ada68
3293e9fd-37dd-4f0e-9b8c-75c31ee07d2f	9ad8e669-96b2-4a80-9b62-01c2e0ce83b7
21a7ccab-f27c-4bd6-8f34-2ca60d790608	38b69e99-f3e9-4ff5-8c55-4391a8ffeb04
38b69e99-f3e9-4ff5-8c55-4391a8ffeb04	b3bbc8e6-8c42-4428-9861-138c73737f57
65822aa7-971b-439f-874f-3d3b5ae899fa	7b19e00f-8601-4a48-a6fb-5aa77e5c3aa0
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	54b95eda-38e9-4124-81d9-9c6858cd26cc
55f5d9d4-4544-4b29-a949-9c339a088af6	84455d71-af6b-4c06-9960-ad6409e95363
21a7ccab-f27c-4bd6-8f34-2ca60d790608	cbb2daa4-50ec-4a56-a34f-d47b547a78c8
21a7ccab-f27c-4bd6-8f34-2ca60d790608	4845bfdd-ab43-45ec-bd8d-dc6d0f83f085
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority, version) FROM stdin;
e0088cdd-69d2-4e0e-8d59-4954f6d8e9f7	\N	password	e4d137a8-ca21-4bd5-80dc-69cee3432bdb	1751384473853	\N	{"value":"TG4wOQkngTkrERyjMmVuEuML8EIIK2uo4tAfi6Ph5Uc=","salt":"MBRh6tTR4+NIjffLYn338A==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	0
90ac798b-4438-4e6d-aa1f-a483b4ae3c5b	\N	password	ecacf8de-e81a-4ca7-83d6-d7fc200bf9a4	1751384473918	\N	{"value":"qTsDe5eZpiQE44CyRv63CqG8fdKX5F3PkseCC7S6fck=","salt":"jD1t+8rUXufyhCaMLyfMJg==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	0
791a3304-26b4-47bd-baf0-8d18d66926cc	\N	password	15d36145-5cea-49e5-9f9f-fe71bfe502fb	1751384473963	\N	{"value":"QNc9GjzFHbR+tboMgys+mgapyfGj9ZR5JD6SN+IN0M4=","salt":"fQNSHq/swM05uiey4FBTng==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	0
2376d2bf-5339-4dcf-ab9e-c784d57d4c57	\N	password	c8aa4eda-47e0-47eb-858a-05ca984b208c	1751384474726	\N	{"value":"r8k0cad4y9r33wA4WU4LFeMX2pmoT/8+3eQL3+tNkgA=","salt":"6d26zrv64fKyaDKViomCrA==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10	0
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2025-07-01 15:40:50.834804	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	1384450370
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2025-07-01 15:40:50.858489	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	1384450370
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2025-07-01 15:40:50.912974	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.29.1	\N	\N	1384450370
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2025-07-01 15:40:50.924317	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	1384450370
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2025-07-01 15:40:51.036627	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	1384450370
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2025-07-01 15:40:51.048448	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	1384450370
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2025-07-01 15:40:51.161661	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	1384450370
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2025-07-01 15:40:51.173529	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	1384450370
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2025-07-01 15:40:51.185266	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.29.1	\N	\N	1384450370
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2025-07-01 15:40:51.302048	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.29.1	\N	\N	1384450370
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2025-07-01 15:40:51.367	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	1384450370
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2025-07-01 15:40:51.375147	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	1384450370
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2025-07-01 15:40:51.408422	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	1384450370
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-07-01 15:40:51.432507	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.29.1	\N	\N	1384450370
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-07-01 15:40:51.437234	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-07-01 15:40:51.443038	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.29.1	\N	\N	1384450370
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2025-07-01 15:40:51.450231	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.29.1	\N	\N	1384450370
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2025-07-01 15:40:51.527085	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.29.1	\N	\N	1384450370
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2025-07-01 15:40:51.574059	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	1384450370
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2025-07-01 15:40:51.584281	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	1384450370
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2025-07-01 15:40:51.591704	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	1384450370
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2025-07-01 15:40:51.596583	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	1384450370
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2025-07-01 15:40:51.735483	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.29.1	\N	\N	1384450370
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2025-07-01 15:40:51.748873	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	1384450370
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2025-07-01 15:40:51.753803	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	1384450370
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2025-07-01 15:40:52.973313	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.29.1	\N	\N	1384450370
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2025-07-01 15:40:53.094712	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.29.1	\N	\N	1384450370
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2025-07-01 15:40:53.110549	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	1384450370
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2025-07-01 15:40:53.208548	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.29.1	\N	\N	1384450370
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2025-07-01 15:40:53.227294	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.29.1	\N	\N	1384450370
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2025-07-01 15:40:53.255529	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.29.1	\N	\N	1384450370
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2025-07-01 15:40:53.264326	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.29.1	\N	\N	1384450370
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-07-01 15:40:53.276503	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-07-01 15:40:53.283055	34	MARK_RAN	9:f9753208029f582525ed12011a19d054	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	1384450370
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-07-01 15:40:53.333466	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	1384450370
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2025-07-01 15:40:53.343816	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.29.1	\N	\N	1384450370
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2025-07-01 15:40:53.353244	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	1384450370
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2025-07-01 15:40:53.362602	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.29.1	\N	\N	1384450370
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2025-07-01 15:40:53.373582	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.29.1	\N	\N	1384450370
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-07-01 15:40:53.378256	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	1384450370
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-07-01 15:40:53.387399	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	1384450370
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2025-07-01 15:40:53.400582	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.29.1	\N	\N	1384450370
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2025-07-01 15:40:58.136791	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.29.1	\N	\N	1384450370
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2025-07-01 15:40:58.250507	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.29.1	\N	\N	1384450370
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-07-01 15:40:58.269398	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	1384450370
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-07-01 15:40:58.282679	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.29.1	\N	\N	1384450370
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-07-01 15:40:58.286959	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	1384450370
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-07-01 15:40:58.70764	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.29.1	\N	\N	1384450370
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2025-07-01 15:40:58.719746	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.29.1	\N	\N	1384450370
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2025-07-01 15:40:58.823762	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.29.1	\N	\N	1384450370
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2025-07-01 15:41:00.998989	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.29.1	\N	\N	1384450370
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2025-07-01 15:41:01.006483	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2025-07-01 15:41:01.014046	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.29.1	\N	\N	1384450370
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2025-07-01 15:41:01.021028	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.29.1	\N	\N	1384450370
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-07-01 15:41:01.036157	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.29.1	\N	\N	1384450370
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-07-01 15:41:01.050685	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.29.1	\N	\N	1384450370
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-07-01 15:41:01.116883	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.29.1	\N	\N	1384450370
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2025-07-01 15:41:01.590259	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.29.1	\N	\N	1384450370
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2025-07-01 15:41:01.6183	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.29.1	\N	\N	1384450370
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2025-07-01 15:41:01.629126	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	1384450370
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-07-01 15:41:01.643678	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.29.1	\N	\N	1384450370
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2025-07-01 15:41:01.652453	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.29.1	\N	\N	1384450370
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2025-07-01 15:41:01.660427	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	1384450370
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2025-07-01 15:41:01.66682	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	1384450370
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2025-07-01 15:41:01.672937	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.29.1	\N	\N	1384450370
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2025-07-01 15:41:01.719441	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.29.1	\N	\N	1384450370
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2025-07-01 15:41:01.760432	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.29.1	\N	\N	1384450370
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2025-07-01 15:41:01.770491	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.29.1	\N	\N	1384450370
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2025-07-01 15:41:01.815932	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.29.1	\N	\N	1384450370
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2025-07-01 15:41:01.826771	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.29.1	\N	\N	1384450370
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2025-07-01 15:41:01.843821	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	1384450370
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-07-01 15:41:01.857309	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	1384450370
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-07-01 15:41:01.871244	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	1384450370
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-07-01 15:41:01.875001	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	1384450370
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-07-01 15:41:01.901065	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.29.1	\N	\N	1384450370
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2025-07-01 15:41:01.949192	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.29.1	\N	\N	1384450370
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-07-01 15:41:01.956196	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.29.1	\N	\N	1384450370
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-07-01 15:41:01.96014	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.29.1	\N	\N	1384450370
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-07-01 15:41:01.98307	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.29.1	\N	\N	1384450370
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2025-07-01 15:41:01.987358	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.29.1	\N	\N	1384450370
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-07-01 15:41:02.026081	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.29.1	\N	\N	1384450370
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-07-01 15:41:02.028487	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	1384450370
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-07-01 15:41:02.03763	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	1384450370
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-07-01 15:41:02.039968	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	1384450370
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2025-07-01 15:41:02.077686	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	1384450370
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2025-07-01 15:41:02.085218	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.29.1	\N	\N	1384450370
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-07-01 15:41:02.097211	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.29.1	\N	\N	1384450370
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2025-07-01 15:41:02.107707	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.29.1	\N	\N	1384450370
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.117772	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.29.1	\N	\N	1384450370
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.127617	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.29.1	\N	\N	1384450370
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.165277	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.177272	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.29.1	\N	\N	1384450370
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.180242	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	1384450370
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.19112	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	1384450370
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.195343	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.29.1	\N	\N	1384450370
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2025-07-01 15:41:02.204671	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.29.1	\N	\N	1384450370
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:02.300716	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:02.304248	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:05.36457	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:05.406911	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:05.410851	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:05.452741	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.29.1	\N	\N	1384450370
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2025-07-01 15:41:05.459557	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.29.1	\N	\N	1384450370
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2025-07-01 15:41:05.471701	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.29.1	\N	\N	1384450370
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2025-07-01 15:41:05.514279	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.29.1	\N	\N	1384450370
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2025-07-01 15:41:05.555548	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	1384450370
18.0.15-30992-index-consent	keycloak	META-INF/jpa-changelog-18.0.15.xml	2025-07-01 15:41:05.603492	107	EXECUTED	9:80071ede7a05604b1f4906f3bf3b00f0	createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE		\N	4.29.1	\N	\N	1384450370
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2025-07-01 15:41:05.610902	108	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.29.1	\N	\N	1384450370
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-07-01 15:41:05.655918	109	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	1384450370
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-07-01 15:41:05.660295	110	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	1384450370
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2025-07-01 15:41:05.671196	111	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2025-07-01 15:41:05.676819	112	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.29.1	\N	\N	1384450370
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-07-01 15:41:05.69114	113	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	1384450370
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2025-07-01 15:41:05.696955	114	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.29.1	\N	\N	1384450370
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2025-07-01 15:41:05.70477	115	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.29.1	\N	\N	1384450370
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2025-07-01 15:41:05.707589	116	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.29.1	\N	\N	1384450370
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2025-07-01 15:41:05.719159	117	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.29.1	\N	\N	1384450370
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2025-07-01 15:41:05.727565	118	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	1384450370
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-07-01 15:41:05.86439	119	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.29.1	\N	\N	1384450370
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-07-01 15:41:05.871258	120	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.29.1	\N	\N	1384450370
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-07-01 15:41:05.879548	121	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2025-07-01 15:41:06.001069	122	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-07-01 15:41:06.008492	123	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.29.1	\N	\N	1384450370
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-07-01 15:41:06.0116	124	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2025-07-01 15:41:06.016898	125	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-tables	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.028019	126	EXECUTED	9:deda2df035df23388af95bbd36c17cef	addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.068049	127	EXECUTED	9:3e96709818458ae49f3c679ae58d263a	createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-cleanup-uss-createdon	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.440093	128	EXECUTED	9:78ab4fc129ed5e8265dbcc3485fba92f	dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-cleanup-uss-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.605013	129	EXECUTED	9:de5f7c1f7e10994ed8b62e621d20eaab	dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-cleanup-uss-by-usersess	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.767489	130	EXECUTED	9:6eee220d024e38e89c799417ec33667f	dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-cleanup-css-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.92254	131	EXECUTED	9:5411d2fb2891d3e8d63ddb55dfa3c0c9	dropIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-2-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.926648	132	MARK_RAN	9:b7ef76036d3126bb83c2423bf4d449d6	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-28265-index-2-not-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.976421	133	EXECUTED	9:23396cf51ab8bc1ae6f0cac7f9f6fcf7	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	1384450370
25.0.0-org	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:06.992645	134	EXECUTED	9:5c859965c2c9b9c72136c360649af157	createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	1384450370
unique-consentuser	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:07.007063	135	EXECUTED	9:5857626a2ea8767e9a6c66bf3a2cb32f	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	1384450370
unique-consentuser-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:07.011437	136	MARK_RAN	9:b79478aad5adaa1bc428e31563f55e8e	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	1384450370
25.0.0-28861-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2025-07-01 15:41:07.087459	137	EXECUTED	9:b9acb58ac958d9ada0fe12a5d4794ab1	createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET		\N	4.29.1	\N	\N	1384450370
26.0.0-org-alias	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.097264	138	EXECUTED	9:6ef7d63e4412b3c2d66ed179159886a4	addColumn tableName=ORG; update tableName=ORG; addNotNullConstraint columnName=ALIAS, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_ALIAS, tableName=ORG		\N	4.29.1	\N	\N	1384450370
26.0.0-org-group	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.107954	139	EXECUTED	9:da8e8087d80ef2ace4f89d8c5b9ca223	addColumn tableName=KEYCLOAK_GROUP; update tableName=KEYCLOAK_GROUP; addNotNullConstraint columnName=TYPE, tableName=KEYCLOAK_GROUP; customChange		\N	4.29.1	\N	\N	1384450370
26.0.0-org-indexes	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.148104	140	EXECUTED	9:79b05dcd610a8c7f25ec05135eec0857	createIndex indexName=IDX_ORG_DOMAIN_ORG_ID, tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	1384450370
26.0.0-org-group-membership	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.158411	141	EXECUTED	9:a6ace2ce583a421d89b01ba2a28dc2d4	addColumn tableName=USER_GROUP_MEMBERSHIP; update tableName=USER_GROUP_MEMBERSHIP; addNotNullConstraint columnName=MEMBERSHIP_TYPE, tableName=USER_GROUP_MEMBERSHIP		\N	4.29.1	\N	\N	1384450370
31296-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.168457	142	EXECUTED	9:64ef94489d42a358e8304b0e245f0ed4	createTable tableName=REVOKED_TOKEN; addPrimaryKey constraintName=CONSTRAINT_RT, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	1384450370
31725-index-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.209722	143	EXECUTED	9:b994246ec2bf7c94da881e1d28782c7b	createIndex indexName=IDX_REV_TOKEN_ON_EXPIRE, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	1384450370
26.0.0-idps-for-login	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.287687	144	EXECUTED	9:51f5fffadf986983d4bd59582c6c1604	addColumn tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_REALM_ORG, tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER; customChange		\N	4.29.1	\N	\N	1384450370
26.0.0-32583-drop-redundant-index-on-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.455525	145	EXECUTED	9:24972d83bf27317a055d234187bb4af9	dropIndex indexName=IDX_US_SESS_ID_ON_CL_SESS, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	1384450370
26.0.0.32582-remove-tables-user-session-user-session-note-and-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.470211	146	EXECUTED	9:febdc0f47f2ed241c59e60f58c3ceea5	dropTable tableName=CLIENT_SESSION_ROLE; dropTable tableName=CLIENT_SESSION_NOTE; dropTable tableName=CLIENT_SESSION_PROT_MAPPER; dropTable tableName=CLIENT_SESSION_AUTH_STATUS; dropTable tableName=CLIENT_USER_SESSION_NOTE; dropTable tableName=CLI...		\N	4.29.1	\N	\N	1384450370
26.0.0-33201-org-redirect-url	keycloak	META-INF/jpa-changelog-26.0.0.xml	2025-07-01 15:41:07.478107	147	EXECUTED	9:4d0e22b0ac68ebe9794fa9cb752ea660	addColumn tableName=ORG		\N	4.29.1	\N	\N	1384450370
29399-jdbc-ping-default	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-07-01 15:41:07.490672	148	EXECUTED	9:007dbe99d7203fca403b89d4edfdf21e	createTable tableName=JGROUPS_PING; addPrimaryKey constraintName=CONSTRAINT_JGROUPS_PING, tableName=JGROUPS_PING		\N	4.29.1	\N	\N	1384450370
26.1.0-34013	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-07-01 15:41:07.524775	149	EXECUTED	9:e6b686a15759aef99a6d758a5c4c6a26	addColumn tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	1384450370
26.1.0-34380	keycloak	META-INF/jpa-changelog-26.1.0.xml	2025-07-01 15:41:07.532752	150	EXECUTED	9:ac8b9edb7c2b6c17a1c7a11fcf5ccf01	dropTable tableName=USERNAME_LOGIN_FAILURE		\N	4.29.1	\N	\N	1384450370
26.2.0-36750	keycloak	META-INF/jpa-changelog-26.2.0.xml	2025-07-01 15:41:07.544315	151	EXECUTED	9:b49ce951c22f7eb16480ff085640a33a	createTable tableName=SERVER_CONFIG		\N	4.29.1	\N	\N	1384450370
26.2.0-26106	keycloak	META-INF/jpa-changelog-26.2.0.xml	2025-07-01 15:41:07.553349	152	EXECUTED	9:b5877d5dab7d10ff3a9d209d7beb6680	addColumn tableName=CREDENTIAL		\N	4.29.1	\N	\N	1384450370
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	2d130128-6b0f-4a1c-935a-f8761a4ab63f	f
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	d7a8c698-f0b2-4433-a2be-b06cea303ee7	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	cd9b2dff-e030-44bd-814d-bf7ae7e0de3b	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	c6266124-fda5-40ae-9d53-f2fad8c47976	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	6cd5db78-03b2-493f-81ba-e4acd74e44c6	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	53075a4e-df7c-45c3-ae11-b1280ac1d580	f
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	d021eb96-7654-4a18-ad38-8f5ad86baf24	f
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	796d1d68-2914-4b36-bffb-4580c977ea54	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	86b56408-5c52-4f25-9da8-ad51cb65e26d	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	fbca5fcb-7ba3-4e9d-93a3-adf0298de659	f
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	23a98e55-01e9-4cee-8696-7cbbc1d6138f	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	15c66c27-1086-419b-bad2-a27ceead1dc0	t
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	571471a6-1e27-4d71-801b-c842c2dc11ca	f
b8bb26cb-496e-4ae0-94bc-8c9268be7494	21862a5a-767c-4bc6-9863-935998fb4070	f
b8bb26cb-496e-4ae0-94bc-8c9268be7494	c4eee212-112e-496f-b99d-537a786c7843	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	46565aae-25e5-4451-a443-c13556dd571e	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	61b5ebfc-2783-4c4f-a746-5408cce8bdeb	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	a7ece06c-6983-4c98-8f8d-a4559293c529	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c	f
b8bb26cb-496e-4ae0-94bc-8c9268be7494	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3	f
b8bb26cb-496e-4ae0-94bc-8c9268be7494	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	103fde5b-c40b-413a-a01e-ee8c04cc6efd	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	ddefb625-6062-446d-804c-72b962e7f330	f
b8bb26cb-496e-4ae0-94bc-8c9268be7494	2464429d-4856-4d59-976f-40e1e066fa19	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	364149a4-5707-4969-a163-224dc227ec55	t
b8bb26cb-496e-4ae0-94bc-8c9268be7494	77e2ccf9-8143-4935-9800-9986feb17b01	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only, organization_id, hide_on_login) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: jgroups_ping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.jgroups_ping (address, name, cluster_name, ip, coord) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.keycloak_group (id, name, parent_group, realm_id, type) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
6dd805e3-8294-4275-8426-5a6940872806	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	${role_default-roles}	default-roles-master	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	\N
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	${role_admin}	admin	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	\N
3ca7820f-59a9-45ae-bd95-f75a1855a6d9	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	${role_create-realm}	create-realm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	\N
76bafc5f-bb0c-4655-bf77-2d1dad29a0df	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_create-client}	create-client	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
abc6ad36-4e27-4738-af9d-690ee9d0de74	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-realm}	view-realm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
7aaea338-a2bd-49d9-b1dd-37bbc908a3f1	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-users}	view-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
821984f5-644d-42cc-9621-3952dfcde2a2	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-clients}	view-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
26e3c81f-4ce6-466c-ba00-110c23709240	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-events}	view-events	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
414617f5-9e45-4fdc-aca8-863fc82782f0	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-identity-providers}	view-identity-providers	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
0e7f57df-e111-4af8-9494-b31e0288c39b	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_view-authorization}	view-authorization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
126133e0-2aec-4486-844c-86e335e9e2e1	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-realm}	manage-realm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
c49c1c0d-3873-4a37-9e79-3340f606d078	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-users}	manage-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
7d4e1ed1-78fe-409a-80fa-097a0136f27e	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-clients}	manage-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
1b143649-25e9-41c4-9668-6ae4e756e1ec	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-events}	manage-events	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
6532f036-08af-4d0e-be1a-0394ae886cc9	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-identity-providers}	manage-identity-providers	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
99c37b35-6acd-4b22-9f3e-06564ffbce29	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_manage-authorization}	manage-authorization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
3f042a23-09f1-48f1-aee1-3197c4cdb4dc	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_query-users}	query-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
f93756b5-a87f-48e9-a1f4-3b4506337128	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_query-clients}	query-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
c19bb22e-704d-4926-b6a2-dace7cfe2a6f	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_query-realms}	query-realms	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
74445586-64e7-45a2-804c-75d87be746f0	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_query-groups}	query-groups	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
07be1f47-7098-4bec-be9e-ad4b12628c13	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_view-profile}	view-profile	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
8c9da990-75a7-4fc1-9297-0c9ca92ff2c0	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_manage-account}	manage-account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
5f64800b-6cc9-46db-9a93-04aa5fa96ec9	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_manage-account-links}	manage-account-links	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
11b00644-abfa-4a7f-a239-d07d0d88a17e	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_view-applications}	view-applications	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
bc08fff4-eb3b-453c-8d5c-0f0ee4515e27	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_view-consent}	view-consent	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
06a9bc3f-3114-48da-8b9e-34430d2d8468	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_manage-consent}	manage-consent	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
f5d891bc-48f4-4df8-868f-31683a4b4630	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_view-groups}	view-groups	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
64772a93-dc3f-4c6e-a5d7-f0ded4ddb4a5	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	t	${role_delete-account}	delete-account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	41589de5-a9a8-4b43-b9b8-5aee3d9ac351	\N
d373293d-7c02-41be-b8fc-4ed2def9cf5a	65973d02-362c-4c14-87c6-20fe07c58f5f	t	${role_read-token}	read-token	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	65973d02-362c-4c14-87c6-20fe07c58f5f	\N
36aa9915-617c-46a7-8fe8-c3ae21013027	7ec446a5-c642-4994-b419-0806329b58bf	t	${role_impersonation}	impersonation	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	7ec446a5-c642-4994-b419-0806329b58bf	\N
a4199a7d-c4a8-4f13-9e7b-eac0de4f9be7	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	${role_offline-access}	offline_access	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	\N
5ca207fa-947e-48a9-b48e-6c4d5b17cbe1	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	${role_uma_authorization}	uma_authorization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	\N	\N
21a7ccab-f27c-4bd6-8f34-2ca60d790608	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f	${role_default-roles}	default-roles-nextjs-dashboard	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N	\N
8b12a05c-866e-43d4-8b8f-6fbbc57d459f	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_create-client}	create-client	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
4db61c65-95a8-4f7b-89ad-4a1936a68371	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-realm}	view-realm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
d01dfa0f-40a0-4f1f-afb0-a5641ba4ca67	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-users}	view-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
0a8ae95b-b6ca-4d80-aec4-f8c8a1b0673a	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-clients}	view-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
e2ee9e8f-9294-4d7b-bc9c-8186acb95cb0	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-events}	view-events	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
4c7b4cf8-7182-4a45-9a32-0d38da165a26	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-identity-providers}	view-identity-providers	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
ae61f5fb-493b-4a0e-8417-bff9f9197d79	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_view-authorization}	view-authorization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
9defc2b8-4446-49a8-b7da-5456d3a4cd44	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-realm}	manage-realm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
e2b804ef-82e8-4a51-85a3-0b2069cf8481	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-users}	manage-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
b461aaf2-a3f4-4995-a85a-2c0de29a80d4	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-clients}	manage-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
f5d3c9d8-fcc8-44ac-a1ad-24cc4ed0a1f5	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-events}	manage-events	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
981ca916-157d-407e-829d-50d446eb705c	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-identity-providers}	manage-identity-providers	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
dc05abae-c052-40f5-9321-143d8dc05f8a	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_manage-authorization}	manage-authorization	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
cdd43fdd-751e-45ce-9c7f-42574ce567f6	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_query-users}	query-users	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
34975fd1-7393-4c01-aa02-f4ddb7929016	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_query-clients}	query-clients	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
0ea82cc4-0667-4991-b120-397a595680dc	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_query-realms}	query-realms	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
c17a655d-e93a-40f9-b80f-d09f425c0f67	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_query-groups}	query-groups	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
55f5d9d4-4544-4b29-a949-9c339a088af6	425e27a1-0201-4864-a8da-1389309f3991	t	${role_realm-admin}	realm-admin	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
651bf7b7-f483-4cf4-8ff3-1c288a81418a	425e27a1-0201-4864-a8da-1389309f3991	t	${role_create-client}	create-client	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
b0b4e6fb-db39-4edf-a8ad-cc8cfabe180e	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-realm}	view-realm	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
3293e9fd-37dd-4f0e-9b8c-75c31ee07d2f	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-users}	view-users	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
23d770d4-a237-44e3-8e8a-1115e200c5cd	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-clients}	view-clients	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
02e38170-4541-4277-a557-ef53a5b46932	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-events}	view-events	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
151aaa5c-8496-434b-8f2a-98d2b5674cb2	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-identity-providers}	view-identity-providers	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
fb642436-9506-4c94-baf5-d94a11e7bd93	425e27a1-0201-4864-a8da-1389309f3991	t	${role_view-authorization}	view-authorization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
6a784e1c-3936-4d81-a559-c4c0c0521478	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-realm}	manage-realm	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
623e49d5-946a-4be3-bebb-94d6d5a65919	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-users}	manage-users	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
cd21218f-9a40-4b58-951b-1e871a3995e1	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-clients}	manage-clients	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
0f3935d9-5f93-4426-9c9f-8edacdb49539	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-events}	manage-events	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
fb945b21-4cba-46cb-b3b3-be386c0c1e90	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-identity-providers}	manage-identity-providers	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
6fcbf27d-510c-4b47-8b17-b6c77037e53d	425e27a1-0201-4864-a8da-1389309f3991	t	${role_manage-authorization}	manage-authorization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
4261522f-b425-4556-9227-b52d122ada68	425e27a1-0201-4864-a8da-1389309f3991	t	${role_query-users}	query-users	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
d7e9f0f0-1982-47fd-9ec8-b3fefde92ff0	425e27a1-0201-4864-a8da-1389309f3991	t	${role_query-clients}	query-clients	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
8930d296-b2ee-41ff-bd0a-390a2e2d29eb	425e27a1-0201-4864-a8da-1389309f3991	t	${role_query-realms}	query-realms	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
9ad8e669-96b2-4a80-9b62-01c2e0ce83b7	425e27a1-0201-4864-a8da-1389309f3991	t	${role_query-groups}	query-groups	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
f709646e-93c8-4cdc-b344-ef093ff83d71	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_view-profile}	view-profile	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
38b69e99-f3e9-4ff5-8c55-4391a8ffeb04	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_manage-account}	manage-account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
b3bbc8e6-8c42-4428-9861-138c73737f57	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_manage-account-links}	manage-account-links	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
4bc55383-d6b6-4250-a200-dbf1ab0a7284	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_view-applications}	view-applications	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
7b19e00f-8601-4a48-a6fb-5aa77e5c3aa0	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_view-consent}	view-consent	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
65822aa7-971b-439f-874f-3d3b5ae899fa	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_manage-consent}	manage-consent	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
c7f4f2ad-cc30-4b4f-9244-e08a3bb980b1	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_view-groups}	view-groups	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
8fe42734-2847-4292-923d-d75c633ae62b	93f2c134-c670-4909-985e-fe010ba0387f	t	${role_delete-account}	delete-account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	93f2c134-c670-4909-985e-fe010ba0387f	\N
54b95eda-38e9-4124-81d9-9c6858cd26cc	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	t	${role_impersonation}	impersonation	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	\N
84455d71-af6b-4c06-9960-ad6409e95363	425e27a1-0201-4864-a8da-1389309f3991	t	${role_impersonation}	impersonation	b8bb26cb-496e-4ae0-94bc-8c9268be7494	425e27a1-0201-4864-a8da-1389309f3991	\N
60855388-e5da-4468-a559-10e1cb4d6d20	d022457d-23f0-43de-a367-5764a1002542	t	${role_read-token}	read-token	b8bb26cb-496e-4ae0-94bc-8c9268be7494	d022457d-23f0-43de-a367-5764a1002542	\N
cbb2daa4-50ec-4a56-a34f-d47b547a78c8	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f	${role_offline-access}	offline_access	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N	\N
67a08dd2-d51c-47e9-98eb-decdfc90c8f2	b658886f-d909-4c90-b9d9-567d24212b2c	t	Role for Dashboard Admins in Parkigo client	dashboard_admin	b8bb26cb-496e-4ae0-94bc-8c9268be7494	b658886f-d909-4c90-b9d9-567d24212b2c	\N
d670c10d-b421-4e98-aa48-04dd9030522e	b658886f-d909-4c90-b9d9-567d24212b2c	t	Role for Dashboard Owners in Parkigo client	dashboard_owner	b8bb26cb-496e-4ae0-94bc-8c9268be7494	b658886f-d909-4c90-b9d9-567d24212b2c	\N
4a4dd9e6-31da-4392-a818-18308f685e32	b658886f-d909-4c90-b9d9-567d24212b2c	t	Role for Dashboard Renters in Parkigo client	dashboard_renter	b8bb26cb-496e-4ae0-94bc-8c9268be7494	b658886f-d909-4c90-b9d9-567d24212b2c	\N
4845bfdd-ab43-45ec-bd8d-dc6d0f83f085	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f	${role_uma_authorization}	uma_authorization	b8bb26cb-496e-4ae0-94bc-8c9268be7494	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.migration_model (id, version, update_time) FROM stdin;
wqhi2	26.2.5	1751384469
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id, version) FROM stdin;
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh, broker_session_id, version) FROM stdin;
\.


--
-- Data for Name: org; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.org (id, enabled, realm_id, group_id, name, description, alias, redirect_url) FROM stdin;
\.


--
-- Data for Name: org_domain; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.org_domain (id, name, verified, org_id) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
734bf801-e42c-4efd-b7a4-f0b8eaa54dc7	audience resolve	openid-connect	oidc-audience-resolve-mapper	0f762526-c25a-452c-92f9-6c00cbc28295	\N
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	locale	openid-connect	oidc-usermodel-attribute-mapper	70e2e715-8e79-4b85-979a-9b96a357ddb9	\N
77576027-f2c2-4c70-a749-07aca48e7e95	role list	saml	saml-role-list-mapper	\N	d7a8c698-f0b2-4433-a2be-b06cea303ee7
3dd68540-080c-42bf-9bb5-fa490e3c1398	organization	saml	saml-organization-membership-mapper	\N	cd9b2dff-e030-44bd-814d-bf7ae7e0de3b
36e41d61-bcd2-4d5e-a34d-c03cbbf91d79	full name	openid-connect	oidc-full-name-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
11ef01c7-2d27-4140-8125-17dcba40d1e7	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
cff920d6-df09-4d17-a0fa-687bcc4375de	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
c83387e0-ccef-4464-84cb-a7dbc4c68691	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
01f3d1be-936d-4922-a061-f9192bfa3a94	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
f33c31d4-755b-4dc8-8741-486135daf086	username	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
ae4248c6-22ac-46b9-866e-f49b99dff91b	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
5101d259-b102-485a-8178-13ad56fea59d	website	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
0af1b47c-98f3-460b-be12-435ad0f7a8c9	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
620ec690-c1d2-4f03-8b62-3833f098df64	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
92b9cdc7-ab33-4187-beaa-301badfda40b	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
c4ed6fea-d9ae-448f-b832-1c624fa3faac	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
fb2e0641-324e-430f-85f7-6371c48b5d62	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	c6266124-fda5-40ae-9d53-f2fad8c47976
2989f55e-2746-4462-ade3-60e6da7b9e41	email	openid-connect	oidc-usermodel-attribute-mapper	\N	6cd5db78-03b2-493f-81ba-e4acd74e44c6
30a669e5-f593-494a-922e-915d7ae360d1	email verified	openid-connect	oidc-usermodel-property-mapper	\N	6cd5db78-03b2-493f-81ba-e4acd74e44c6
a846f0d6-c8c4-4664-8d2f-048ba6679314	address	openid-connect	oidc-address-mapper	\N	53075a4e-df7c-45c3-ae11-b1280ac1d580
24c0ee27-a7ad-4062-a643-8261743230c9	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	d021eb96-7654-4a18-ad38-8f5ad86baf24
7ca33c82-e121-4072-aa24-fdb6baa90146	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	d021eb96-7654-4a18-ad38-8f5ad86baf24
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	796d1d68-2914-4b36-bffb-4580c977ea54
01909616-3aa0-41c5-960f-19a750829bba	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	796d1d68-2914-4b36-bffb-4580c977ea54
37aec032-6898-4330-9aa7-5a577184e503	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	796d1d68-2914-4b36-bffb-4580c977ea54
c8867e38-5048-4a29-9426-6dc10ba36cdb	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	86b56408-5c52-4f25-9da8-ad51cb65e26d
76e698f8-839d-49b2-9e83-df8775f3056a	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	fbca5fcb-7ba3-4e9d-93a3-adf0298de659
601c40b4-d3d7-43d5-925f-50ed5cf12672	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	fbca5fcb-7ba3-4e9d-93a3-adf0298de659
32eec251-c2e2-4852-b568-1a9c141a14c8	acr loa level	openid-connect	oidc-acr-mapper	\N	23a98e55-01e9-4cee-8696-7cbbc1d6138f
364f5ce7-e48c-44ae-b049-48cf61553f61	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	15c66c27-1086-419b-bad2-a27ceead1dc0
6892de5d-f0b2-4017-8659-484cc6cd58f3	sub	openid-connect	oidc-sub-mapper	\N	15c66c27-1086-419b-bad2-a27ceead1dc0
ce0debbe-20bf-4b72-920c-969475689523	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	d9fa4350-de11-428e-b2fa-68019bd14976
1ea783bb-f7e4-4943-996e-dadfcfb88e18	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	d9fa4350-de11-428e-b2fa-68019bd14976
546b8179-17b9-44d2-abea-d639e3a72f1b	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	d9fa4350-de11-428e-b2fa-68019bd14976
a76a3b25-667e-4b48-ab74-5ec5bafad825	organization	openid-connect	oidc-organization-membership-mapper	\N	571471a6-1e27-4d71-801b-c842c2dc11ca
9665ed68-b956-4093-b9b8-a9ffca6885e3	audience resolve	openid-connect	oidc-audience-resolve-mapper	da945e89-e174-4986-8638-ede57a2b5c50	\N
82342ac0-efa1-46a3-aeda-83af9c06e660	role list	saml	saml-role-list-mapper	\N	c4eee212-112e-496f-b99d-537a786c7843
fb23d387-6fe3-46ed-94cb-951d94d2b5f4	organization	saml	saml-organization-membership-mapper	\N	46565aae-25e5-4451-a443-c13556dd571e
8833da52-a8b5-484b-bf5b-677395ef7c3e	full name	openid-connect	oidc-full-name-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
ac8f120e-a266-4ba3-b7e7-908a409ed042	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
2d309448-f36c-4176-91b6-6f1e1e64448d	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
83bc178a-175e-4d40-addf-b3a24daf7a89	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
4d865290-b9b1-4f69-aafe-42405309b101	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
09b24e10-7a91-4feb-9b34-5e8087146ae4	username	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
81e817d1-f3de-4375-bdb4-aca8a2ecff94	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
c978af04-de52-407c-8261-6631acc9f3c6	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
82f2cfeb-682e-4198-8d7c-00f708072033	website	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
b1aff766-3e06-46fc-9517-93b139ff2e74	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
dadfc729-692d-405b-a607-f7be72d5857a	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
4e018be7-8115-4101-bc3f-4d6fb67d5a37	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	61b5ebfc-2783-4c4f-a746-5408cce8bdeb
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	email	openid-connect	oidc-usermodel-attribute-mapper	\N	a7ece06c-6983-4c98-8f8d-a4559293c529
5b267e2c-715e-42e5-8a96-b2bd680b9d58	email verified	openid-connect	oidc-usermodel-property-mapper	\N	a7ece06c-6983-4c98-8f8d-a4559293c529
942ad4a2-224e-48ff-afcb-ecfdec678b43	address	openid-connect	oidc-address-mapper	\N	cf202bd3-e32c-49b6-bd4d-9bb81e717c1c
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	89ec6aaf-e357-4a3a-b157-2ff4cb988ca3
d71118a9-3047-447b-832c-82267de254b3	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0
09cc4820-d574-4751-bc36-327dcf74459c	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	661e4c0f-ab7d-4339-87d7-fdaab34ae2c0
53adcf69-158e-40c0-aa25-25a97f118f28	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	103fde5b-c40b-413a-a01e-ee8c04cc6efd
277272f6-0838-44b5-8550-7e16e31bac81	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	ddefb625-6062-446d-804c-72b962e7f330
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	ddefb625-6062-446d-804c-72b962e7f330
eb60ea27-47c2-4e95-910b-364f325a6a28	acr loa level	openid-connect	oidc-acr-mapper	\N	2464429d-4856-4d59-976f-40e1e066fa19
3b53c3ec-58a6-426e-89af-a9a2a1f76955	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	364149a4-5707-4969-a163-224dc227ec55
08af6453-44eb-4d17-8cb0-5c4ac7b2dbb1	sub	openid-connect	oidc-sub-mapper	\N	364149a4-5707-4969-a163-224dc227ec55
d473c81b-182c-4f65-b7a6-4fa755a68c4c	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	f80d48ca-4a8d-4418-b062-3a463dc6eff8
36002dd9-859f-450a-843a-c4ba7f836bd5	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	f80d48ca-4a8d-4418-b062-3a463dc6eff8
5b3a351f-75b6-44f6-870d-8d41e145a4a6	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	f80d48ca-4a8d-4418-b062-3a463dc6eff8
13cd259b-ca58-400d-a9c6-d89728cdc39d	organization	openid-connect	oidc-organization-membership-mapper	\N	77e2ccf9-8143-4935-9800-9986feb17b01
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	client roles in id token	openid-connect	oidc-usermodel-client-role-mapper	b658886f-d909-4c90-b9d9-567d24212b2c	\N
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	locale	openid-connect	oidc-usermodel-attribute-mapper	d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	true	introspection.token.claim
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	true	userinfo.token.claim
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	locale	user.attribute
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	true	id.token.claim
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	true	access.token.claim
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	locale	claim.name
8b42073f-3a47-4ac5-998a-76f9c2e5fbb4	String	jsonType.label
77576027-f2c2-4c70-a749-07aca48e7e95	false	single
77576027-f2c2-4c70-a749-07aca48e7e95	Basic	attribute.nameformat
77576027-f2c2-4c70-a749-07aca48e7e95	Role	attribute.name
01f3d1be-936d-4922-a061-f9192bfa3a94	true	introspection.token.claim
01f3d1be-936d-4922-a061-f9192bfa3a94	true	userinfo.token.claim
01f3d1be-936d-4922-a061-f9192bfa3a94	nickname	user.attribute
01f3d1be-936d-4922-a061-f9192bfa3a94	true	id.token.claim
01f3d1be-936d-4922-a061-f9192bfa3a94	true	access.token.claim
01f3d1be-936d-4922-a061-f9192bfa3a94	nickname	claim.name
01f3d1be-936d-4922-a061-f9192bfa3a94	String	jsonType.label
0af1b47c-98f3-460b-be12-435ad0f7a8c9	true	introspection.token.claim
0af1b47c-98f3-460b-be12-435ad0f7a8c9	true	userinfo.token.claim
0af1b47c-98f3-460b-be12-435ad0f7a8c9	gender	user.attribute
0af1b47c-98f3-460b-be12-435ad0f7a8c9	true	id.token.claim
0af1b47c-98f3-460b-be12-435ad0f7a8c9	true	access.token.claim
0af1b47c-98f3-460b-be12-435ad0f7a8c9	gender	claim.name
0af1b47c-98f3-460b-be12-435ad0f7a8c9	String	jsonType.label
11ef01c7-2d27-4140-8125-17dcba40d1e7	true	introspection.token.claim
11ef01c7-2d27-4140-8125-17dcba40d1e7	true	userinfo.token.claim
11ef01c7-2d27-4140-8125-17dcba40d1e7	lastName	user.attribute
11ef01c7-2d27-4140-8125-17dcba40d1e7	true	id.token.claim
11ef01c7-2d27-4140-8125-17dcba40d1e7	true	access.token.claim
11ef01c7-2d27-4140-8125-17dcba40d1e7	family_name	claim.name
11ef01c7-2d27-4140-8125-17dcba40d1e7	String	jsonType.label
36e41d61-bcd2-4d5e-a34d-c03cbbf91d79	true	introspection.token.claim
36e41d61-bcd2-4d5e-a34d-c03cbbf91d79	true	userinfo.token.claim
36e41d61-bcd2-4d5e-a34d-c03cbbf91d79	true	id.token.claim
36e41d61-bcd2-4d5e-a34d-c03cbbf91d79	true	access.token.claim
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	true	introspection.token.claim
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	true	userinfo.token.claim
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	picture	user.attribute
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	true	id.token.claim
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	true	access.token.claim
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	picture	claim.name
3e6ebd83-a693-4f9a-ae54-695a80fd2bad	String	jsonType.label
5101d259-b102-485a-8178-13ad56fea59d	true	introspection.token.claim
5101d259-b102-485a-8178-13ad56fea59d	true	userinfo.token.claim
5101d259-b102-485a-8178-13ad56fea59d	website	user.attribute
5101d259-b102-485a-8178-13ad56fea59d	true	id.token.claim
5101d259-b102-485a-8178-13ad56fea59d	true	access.token.claim
5101d259-b102-485a-8178-13ad56fea59d	website	claim.name
5101d259-b102-485a-8178-13ad56fea59d	String	jsonType.label
620ec690-c1d2-4f03-8b62-3833f098df64	true	introspection.token.claim
620ec690-c1d2-4f03-8b62-3833f098df64	true	userinfo.token.claim
620ec690-c1d2-4f03-8b62-3833f098df64	birthdate	user.attribute
620ec690-c1d2-4f03-8b62-3833f098df64	true	id.token.claim
620ec690-c1d2-4f03-8b62-3833f098df64	true	access.token.claim
620ec690-c1d2-4f03-8b62-3833f098df64	birthdate	claim.name
620ec690-c1d2-4f03-8b62-3833f098df64	String	jsonType.label
92b9cdc7-ab33-4187-beaa-301badfda40b	true	introspection.token.claim
92b9cdc7-ab33-4187-beaa-301badfda40b	true	userinfo.token.claim
92b9cdc7-ab33-4187-beaa-301badfda40b	zoneinfo	user.attribute
92b9cdc7-ab33-4187-beaa-301badfda40b	true	id.token.claim
92b9cdc7-ab33-4187-beaa-301badfda40b	true	access.token.claim
92b9cdc7-ab33-4187-beaa-301badfda40b	zoneinfo	claim.name
92b9cdc7-ab33-4187-beaa-301badfda40b	String	jsonType.label
ae4248c6-22ac-46b9-866e-f49b99dff91b	true	introspection.token.claim
ae4248c6-22ac-46b9-866e-f49b99dff91b	true	userinfo.token.claim
ae4248c6-22ac-46b9-866e-f49b99dff91b	profile	user.attribute
ae4248c6-22ac-46b9-866e-f49b99dff91b	true	id.token.claim
ae4248c6-22ac-46b9-866e-f49b99dff91b	true	access.token.claim
ae4248c6-22ac-46b9-866e-f49b99dff91b	profile	claim.name
ae4248c6-22ac-46b9-866e-f49b99dff91b	String	jsonType.label
c4ed6fea-d9ae-448f-b832-1c624fa3faac	true	introspection.token.claim
c4ed6fea-d9ae-448f-b832-1c624fa3faac	true	userinfo.token.claim
c4ed6fea-d9ae-448f-b832-1c624fa3faac	locale	user.attribute
c4ed6fea-d9ae-448f-b832-1c624fa3faac	true	id.token.claim
c4ed6fea-d9ae-448f-b832-1c624fa3faac	true	access.token.claim
c4ed6fea-d9ae-448f-b832-1c624fa3faac	locale	claim.name
c4ed6fea-d9ae-448f-b832-1c624fa3faac	String	jsonType.label
c83387e0-ccef-4464-84cb-a7dbc4c68691	true	introspection.token.claim
c83387e0-ccef-4464-84cb-a7dbc4c68691	true	userinfo.token.claim
c83387e0-ccef-4464-84cb-a7dbc4c68691	middleName	user.attribute
c83387e0-ccef-4464-84cb-a7dbc4c68691	true	id.token.claim
c83387e0-ccef-4464-84cb-a7dbc4c68691	true	access.token.claim
c83387e0-ccef-4464-84cb-a7dbc4c68691	middle_name	claim.name
c83387e0-ccef-4464-84cb-a7dbc4c68691	String	jsonType.label
cff920d6-df09-4d17-a0fa-687bcc4375de	true	introspection.token.claim
cff920d6-df09-4d17-a0fa-687bcc4375de	true	userinfo.token.claim
cff920d6-df09-4d17-a0fa-687bcc4375de	firstName	user.attribute
cff920d6-df09-4d17-a0fa-687bcc4375de	true	id.token.claim
cff920d6-df09-4d17-a0fa-687bcc4375de	true	access.token.claim
cff920d6-df09-4d17-a0fa-687bcc4375de	given_name	claim.name
cff920d6-df09-4d17-a0fa-687bcc4375de	String	jsonType.label
f33c31d4-755b-4dc8-8741-486135daf086	true	introspection.token.claim
f33c31d4-755b-4dc8-8741-486135daf086	true	userinfo.token.claim
f33c31d4-755b-4dc8-8741-486135daf086	username	user.attribute
f33c31d4-755b-4dc8-8741-486135daf086	true	id.token.claim
f33c31d4-755b-4dc8-8741-486135daf086	true	access.token.claim
f33c31d4-755b-4dc8-8741-486135daf086	preferred_username	claim.name
f33c31d4-755b-4dc8-8741-486135daf086	String	jsonType.label
fb2e0641-324e-430f-85f7-6371c48b5d62	true	introspection.token.claim
fb2e0641-324e-430f-85f7-6371c48b5d62	true	userinfo.token.claim
fb2e0641-324e-430f-85f7-6371c48b5d62	updatedAt	user.attribute
fb2e0641-324e-430f-85f7-6371c48b5d62	true	id.token.claim
fb2e0641-324e-430f-85f7-6371c48b5d62	true	access.token.claim
fb2e0641-324e-430f-85f7-6371c48b5d62	updated_at	claim.name
fb2e0641-324e-430f-85f7-6371c48b5d62	long	jsonType.label
2989f55e-2746-4462-ade3-60e6da7b9e41	true	introspection.token.claim
2989f55e-2746-4462-ade3-60e6da7b9e41	true	userinfo.token.claim
2989f55e-2746-4462-ade3-60e6da7b9e41	email	user.attribute
2989f55e-2746-4462-ade3-60e6da7b9e41	true	id.token.claim
2989f55e-2746-4462-ade3-60e6da7b9e41	true	access.token.claim
2989f55e-2746-4462-ade3-60e6da7b9e41	email	claim.name
2989f55e-2746-4462-ade3-60e6da7b9e41	String	jsonType.label
30a669e5-f593-494a-922e-915d7ae360d1	true	introspection.token.claim
30a669e5-f593-494a-922e-915d7ae360d1	true	userinfo.token.claim
30a669e5-f593-494a-922e-915d7ae360d1	emailVerified	user.attribute
30a669e5-f593-494a-922e-915d7ae360d1	true	id.token.claim
30a669e5-f593-494a-922e-915d7ae360d1	true	access.token.claim
30a669e5-f593-494a-922e-915d7ae360d1	email_verified	claim.name
30a669e5-f593-494a-922e-915d7ae360d1	boolean	jsonType.label
a846f0d6-c8c4-4664-8d2f-048ba6679314	formatted	user.attribute.formatted
a846f0d6-c8c4-4664-8d2f-048ba6679314	country	user.attribute.country
a846f0d6-c8c4-4664-8d2f-048ba6679314	true	introspection.token.claim
a846f0d6-c8c4-4664-8d2f-048ba6679314	postal_code	user.attribute.postal_code
a846f0d6-c8c4-4664-8d2f-048ba6679314	true	userinfo.token.claim
a846f0d6-c8c4-4664-8d2f-048ba6679314	street	user.attribute.street
a846f0d6-c8c4-4664-8d2f-048ba6679314	true	id.token.claim
a846f0d6-c8c4-4664-8d2f-048ba6679314	region	user.attribute.region
a846f0d6-c8c4-4664-8d2f-048ba6679314	true	access.token.claim
a846f0d6-c8c4-4664-8d2f-048ba6679314	locality	user.attribute.locality
24c0ee27-a7ad-4062-a643-8261743230c9	true	introspection.token.claim
24c0ee27-a7ad-4062-a643-8261743230c9	true	userinfo.token.claim
24c0ee27-a7ad-4062-a643-8261743230c9	phoneNumber	user.attribute
24c0ee27-a7ad-4062-a643-8261743230c9	true	id.token.claim
24c0ee27-a7ad-4062-a643-8261743230c9	true	access.token.claim
24c0ee27-a7ad-4062-a643-8261743230c9	phone_number	claim.name
24c0ee27-a7ad-4062-a643-8261743230c9	String	jsonType.label
7ca33c82-e121-4072-aa24-fdb6baa90146	true	introspection.token.claim
7ca33c82-e121-4072-aa24-fdb6baa90146	true	userinfo.token.claim
7ca33c82-e121-4072-aa24-fdb6baa90146	phoneNumberVerified	user.attribute
7ca33c82-e121-4072-aa24-fdb6baa90146	true	id.token.claim
7ca33c82-e121-4072-aa24-fdb6baa90146	true	access.token.claim
7ca33c82-e121-4072-aa24-fdb6baa90146	phone_number_verified	claim.name
7ca33c82-e121-4072-aa24-fdb6baa90146	boolean	jsonType.label
01909616-3aa0-41c5-960f-19a750829bba	true	introspection.token.claim
01909616-3aa0-41c5-960f-19a750829bba	true	multivalued
01909616-3aa0-41c5-960f-19a750829bba	foo	user.attribute
01909616-3aa0-41c5-960f-19a750829bba	true	access.token.claim
01909616-3aa0-41c5-960f-19a750829bba	resource_access.${client_id}.roles	claim.name
01909616-3aa0-41c5-960f-19a750829bba	String	jsonType.label
37aec032-6898-4330-9aa7-5a577184e503	true	introspection.token.claim
37aec032-6898-4330-9aa7-5a577184e503	true	access.token.claim
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	true	introspection.token.claim
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	true	multivalued
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	foo	user.attribute
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	true	access.token.claim
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	realm_access.roles	claim.name
d1f276e5-5f1c-4523-96b6-2ef9ec4a0a22	String	jsonType.label
c8867e38-5048-4a29-9426-6dc10ba36cdb	true	introspection.token.claim
c8867e38-5048-4a29-9426-6dc10ba36cdb	true	access.token.claim
601c40b4-d3d7-43d5-925f-50ed5cf12672	true	introspection.token.claim
601c40b4-d3d7-43d5-925f-50ed5cf12672	true	multivalued
601c40b4-d3d7-43d5-925f-50ed5cf12672	foo	user.attribute
601c40b4-d3d7-43d5-925f-50ed5cf12672	true	id.token.claim
601c40b4-d3d7-43d5-925f-50ed5cf12672	true	access.token.claim
601c40b4-d3d7-43d5-925f-50ed5cf12672	groups	claim.name
601c40b4-d3d7-43d5-925f-50ed5cf12672	String	jsonType.label
76e698f8-839d-49b2-9e83-df8775f3056a	true	introspection.token.claim
76e698f8-839d-49b2-9e83-df8775f3056a	true	userinfo.token.claim
76e698f8-839d-49b2-9e83-df8775f3056a	username	user.attribute
76e698f8-839d-49b2-9e83-df8775f3056a	true	id.token.claim
76e698f8-839d-49b2-9e83-df8775f3056a	true	access.token.claim
76e698f8-839d-49b2-9e83-df8775f3056a	upn	claim.name
76e698f8-839d-49b2-9e83-df8775f3056a	String	jsonType.label
32eec251-c2e2-4852-b568-1a9c141a14c8	true	introspection.token.claim
32eec251-c2e2-4852-b568-1a9c141a14c8	true	id.token.claim
32eec251-c2e2-4852-b568-1a9c141a14c8	true	access.token.claim
364f5ce7-e48c-44ae-b049-48cf61553f61	AUTH_TIME	user.session.note
364f5ce7-e48c-44ae-b049-48cf61553f61	true	introspection.token.claim
364f5ce7-e48c-44ae-b049-48cf61553f61	true	id.token.claim
364f5ce7-e48c-44ae-b049-48cf61553f61	true	access.token.claim
364f5ce7-e48c-44ae-b049-48cf61553f61	auth_time	claim.name
364f5ce7-e48c-44ae-b049-48cf61553f61	long	jsonType.label
6892de5d-f0b2-4017-8659-484cc6cd58f3	true	introspection.token.claim
6892de5d-f0b2-4017-8659-484cc6cd58f3	true	access.token.claim
1ea783bb-f7e4-4943-996e-dadfcfb88e18	clientHost	user.session.note
1ea783bb-f7e4-4943-996e-dadfcfb88e18	true	introspection.token.claim
1ea783bb-f7e4-4943-996e-dadfcfb88e18	true	id.token.claim
1ea783bb-f7e4-4943-996e-dadfcfb88e18	true	access.token.claim
1ea783bb-f7e4-4943-996e-dadfcfb88e18	clientHost	claim.name
1ea783bb-f7e4-4943-996e-dadfcfb88e18	String	jsonType.label
546b8179-17b9-44d2-abea-d639e3a72f1b	clientAddress	user.session.note
546b8179-17b9-44d2-abea-d639e3a72f1b	true	introspection.token.claim
546b8179-17b9-44d2-abea-d639e3a72f1b	true	id.token.claim
546b8179-17b9-44d2-abea-d639e3a72f1b	true	access.token.claim
546b8179-17b9-44d2-abea-d639e3a72f1b	clientAddress	claim.name
546b8179-17b9-44d2-abea-d639e3a72f1b	String	jsonType.label
ce0debbe-20bf-4b72-920c-969475689523	client_id	user.session.note
ce0debbe-20bf-4b72-920c-969475689523	true	introspection.token.claim
ce0debbe-20bf-4b72-920c-969475689523	true	id.token.claim
ce0debbe-20bf-4b72-920c-969475689523	true	access.token.claim
ce0debbe-20bf-4b72-920c-969475689523	client_id	claim.name
ce0debbe-20bf-4b72-920c-969475689523	String	jsonType.label
a76a3b25-667e-4b48-ab74-5ec5bafad825	true	introspection.token.claim
a76a3b25-667e-4b48-ab74-5ec5bafad825	true	multivalued
a76a3b25-667e-4b48-ab74-5ec5bafad825	true	id.token.claim
a76a3b25-667e-4b48-ab74-5ec5bafad825	true	access.token.claim
a76a3b25-667e-4b48-ab74-5ec5bafad825	organization	claim.name
a76a3b25-667e-4b48-ab74-5ec5bafad825	String	jsonType.label
82342ac0-efa1-46a3-aeda-83af9c06e660	false	single
82342ac0-efa1-46a3-aeda-83af9c06e660	Basic	attribute.nameformat
82342ac0-efa1-46a3-aeda-83af9c06e660	Role	attribute.name
09b24e10-7a91-4feb-9b34-5e8087146ae4	true	introspection.token.claim
09b24e10-7a91-4feb-9b34-5e8087146ae4	true	userinfo.token.claim
09b24e10-7a91-4feb-9b34-5e8087146ae4	username	user.attribute
09b24e10-7a91-4feb-9b34-5e8087146ae4	true	id.token.claim
09b24e10-7a91-4feb-9b34-5e8087146ae4	true	access.token.claim
09b24e10-7a91-4feb-9b34-5e8087146ae4	preferred_username	claim.name
09b24e10-7a91-4feb-9b34-5e8087146ae4	String	jsonType.label
2d309448-f36c-4176-91b6-6f1e1e64448d	true	introspection.token.claim
2d309448-f36c-4176-91b6-6f1e1e64448d	true	userinfo.token.claim
2d309448-f36c-4176-91b6-6f1e1e64448d	firstName	user.attribute
2d309448-f36c-4176-91b6-6f1e1e64448d	true	id.token.claim
2d309448-f36c-4176-91b6-6f1e1e64448d	true	access.token.claim
2d309448-f36c-4176-91b6-6f1e1e64448d	given_name	claim.name
2d309448-f36c-4176-91b6-6f1e1e64448d	String	jsonType.label
4d865290-b9b1-4f69-aafe-42405309b101	true	introspection.token.claim
4d865290-b9b1-4f69-aafe-42405309b101	true	userinfo.token.claim
4d865290-b9b1-4f69-aafe-42405309b101	nickname	user.attribute
4d865290-b9b1-4f69-aafe-42405309b101	true	id.token.claim
4d865290-b9b1-4f69-aafe-42405309b101	true	access.token.claim
4d865290-b9b1-4f69-aafe-42405309b101	nickname	claim.name
4d865290-b9b1-4f69-aafe-42405309b101	String	jsonType.label
4e018be7-8115-4101-bc3f-4d6fb67d5a37	true	introspection.token.claim
4e018be7-8115-4101-bc3f-4d6fb67d5a37	true	userinfo.token.claim
4e018be7-8115-4101-bc3f-4d6fb67d5a37	locale	user.attribute
4e018be7-8115-4101-bc3f-4d6fb67d5a37	true	id.token.claim
4e018be7-8115-4101-bc3f-4d6fb67d5a37	true	access.token.claim
4e018be7-8115-4101-bc3f-4d6fb67d5a37	locale	claim.name
4e018be7-8115-4101-bc3f-4d6fb67d5a37	String	jsonType.label
81e817d1-f3de-4375-bdb4-aca8a2ecff94	true	introspection.token.claim
81e817d1-f3de-4375-bdb4-aca8a2ecff94	true	userinfo.token.claim
81e817d1-f3de-4375-bdb4-aca8a2ecff94	profile	user.attribute
81e817d1-f3de-4375-bdb4-aca8a2ecff94	true	id.token.claim
81e817d1-f3de-4375-bdb4-aca8a2ecff94	true	access.token.claim
81e817d1-f3de-4375-bdb4-aca8a2ecff94	profile	claim.name
81e817d1-f3de-4375-bdb4-aca8a2ecff94	String	jsonType.label
82f2cfeb-682e-4198-8d7c-00f708072033	true	introspection.token.claim
82f2cfeb-682e-4198-8d7c-00f708072033	true	userinfo.token.claim
82f2cfeb-682e-4198-8d7c-00f708072033	website	user.attribute
82f2cfeb-682e-4198-8d7c-00f708072033	true	id.token.claim
82f2cfeb-682e-4198-8d7c-00f708072033	true	access.token.claim
82f2cfeb-682e-4198-8d7c-00f708072033	website	claim.name
82f2cfeb-682e-4198-8d7c-00f708072033	String	jsonType.label
83bc178a-175e-4d40-addf-b3a24daf7a89	true	introspection.token.claim
83bc178a-175e-4d40-addf-b3a24daf7a89	true	userinfo.token.claim
83bc178a-175e-4d40-addf-b3a24daf7a89	middleName	user.attribute
83bc178a-175e-4d40-addf-b3a24daf7a89	true	id.token.claim
83bc178a-175e-4d40-addf-b3a24daf7a89	true	access.token.claim
83bc178a-175e-4d40-addf-b3a24daf7a89	middle_name	claim.name
83bc178a-175e-4d40-addf-b3a24daf7a89	String	jsonType.label
8833da52-a8b5-484b-bf5b-677395ef7c3e	true	introspection.token.claim
8833da52-a8b5-484b-bf5b-677395ef7c3e	true	userinfo.token.claim
8833da52-a8b5-484b-bf5b-677395ef7c3e	true	id.token.claim
8833da52-a8b5-484b-bf5b-677395ef7c3e	true	access.token.claim
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	true	introspection.token.claim
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	true	userinfo.token.claim
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	updatedAt	user.attribute
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	true	id.token.claim
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	true	access.token.claim
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	updated_at	claim.name
ac47c6cd-e7a5-4f13-9a3e-e2c0ae3fbf3e	long	jsonType.label
ac8f120e-a266-4ba3-b7e7-908a409ed042	true	introspection.token.claim
ac8f120e-a266-4ba3-b7e7-908a409ed042	true	userinfo.token.claim
ac8f120e-a266-4ba3-b7e7-908a409ed042	lastName	user.attribute
ac8f120e-a266-4ba3-b7e7-908a409ed042	true	id.token.claim
ac8f120e-a266-4ba3-b7e7-908a409ed042	true	access.token.claim
ac8f120e-a266-4ba3-b7e7-908a409ed042	family_name	claim.name
ac8f120e-a266-4ba3-b7e7-908a409ed042	String	jsonType.label
b1aff766-3e06-46fc-9517-93b139ff2e74	true	introspection.token.claim
b1aff766-3e06-46fc-9517-93b139ff2e74	true	userinfo.token.claim
b1aff766-3e06-46fc-9517-93b139ff2e74	gender	user.attribute
b1aff766-3e06-46fc-9517-93b139ff2e74	true	id.token.claim
b1aff766-3e06-46fc-9517-93b139ff2e74	true	access.token.claim
b1aff766-3e06-46fc-9517-93b139ff2e74	gender	claim.name
b1aff766-3e06-46fc-9517-93b139ff2e74	String	jsonType.label
c978af04-de52-407c-8261-6631acc9f3c6	true	introspection.token.claim
c978af04-de52-407c-8261-6631acc9f3c6	true	userinfo.token.claim
c978af04-de52-407c-8261-6631acc9f3c6	picture	user.attribute
c978af04-de52-407c-8261-6631acc9f3c6	true	id.token.claim
c978af04-de52-407c-8261-6631acc9f3c6	true	access.token.claim
c978af04-de52-407c-8261-6631acc9f3c6	picture	claim.name
c978af04-de52-407c-8261-6631acc9f3c6	String	jsonType.label
dadfc729-692d-405b-a607-f7be72d5857a	true	introspection.token.claim
dadfc729-692d-405b-a607-f7be72d5857a	true	userinfo.token.claim
dadfc729-692d-405b-a607-f7be72d5857a	zoneinfo	user.attribute
dadfc729-692d-405b-a607-f7be72d5857a	true	id.token.claim
dadfc729-692d-405b-a607-f7be72d5857a	true	access.token.claim
dadfc729-692d-405b-a607-f7be72d5857a	zoneinfo	claim.name
dadfc729-692d-405b-a607-f7be72d5857a	String	jsonType.label
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	true	introspection.token.claim
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	true	userinfo.token.claim
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	birthdate	user.attribute
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	true	id.token.claim
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	true	access.token.claim
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	birthdate	claim.name
e6f19a1c-ac01-4ab2-b138-f48ee84266c0	String	jsonType.label
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	true	introspection.token.claim
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	true	userinfo.token.claim
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	email	user.attribute
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	true	id.token.claim
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	true	access.token.claim
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	email	claim.name
3bf246ad-eef9-4724-8c4c-81a053f1a5b3	String	jsonType.label
5b267e2c-715e-42e5-8a96-b2bd680b9d58	true	introspection.token.claim
5b267e2c-715e-42e5-8a96-b2bd680b9d58	true	userinfo.token.claim
5b267e2c-715e-42e5-8a96-b2bd680b9d58	emailVerified	user.attribute
5b267e2c-715e-42e5-8a96-b2bd680b9d58	true	id.token.claim
5b267e2c-715e-42e5-8a96-b2bd680b9d58	true	access.token.claim
5b267e2c-715e-42e5-8a96-b2bd680b9d58	email_verified	claim.name
5b267e2c-715e-42e5-8a96-b2bd680b9d58	boolean	jsonType.label
942ad4a2-224e-48ff-afcb-ecfdec678b43	formatted	user.attribute.formatted
942ad4a2-224e-48ff-afcb-ecfdec678b43	country	user.attribute.country
942ad4a2-224e-48ff-afcb-ecfdec678b43	true	introspection.token.claim
942ad4a2-224e-48ff-afcb-ecfdec678b43	postal_code	user.attribute.postal_code
942ad4a2-224e-48ff-afcb-ecfdec678b43	true	userinfo.token.claim
942ad4a2-224e-48ff-afcb-ecfdec678b43	street	user.attribute.street
942ad4a2-224e-48ff-afcb-ecfdec678b43	true	id.token.claim
942ad4a2-224e-48ff-afcb-ecfdec678b43	region	user.attribute.region
942ad4a2-224e-48ff-afcb-ecfdec678b43	true	access.token.claim
942ad4a2-224e-48ff-afcb-ecfdec678b43	locality	user.attribute.locality
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	true	introspection.token.claim
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	true	userinfo.token.claim
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	phoneNumber	user.attribute
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	true	id.token.claim
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	true	access.token.claim
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	phone_number	claim.name
7024d0c0-f2b1-458e-9f2e-60a17aefabfd	String	jsonType.label
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	true	introspection.token.claim
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	true	userinfo.token.claim
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	phoneNumberVerified	user.attribute
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	true	id.token.claim
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	true	access.token.claim
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	phone_number_verified	claim.name
b768f5d8-4990-4bee-9ba5-6e7fd195dd11	boolean	jsonType.label
09cc4820-d574-4751-bc36-327dcf74459c	true	introspection.token.claim
09cc4820-d574-4751-bc36-327dcf74459c	true	access.token.claim
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	true	introspection.token.claim
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	true	multivalued
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	foo	user.attribute
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	true	access.token.claim
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	resource_access.${client_id}.roles	claim.name
a2223b93-cab6-45f6-8be9-7a3dfb2d15ff	String	jsonType.label
d71118a9-3047-447b-832c-82267de254b3	true	introspection.token.claim
d71118a9-3047-447b-832c-82267de254b3	true	multivalued
d71118a9-3047-447b-832c-82267de254b3	foo	user.attribute
d71118a9-3047-447b-832c-82267de254b3	true	access.token.claim
d71118a9-3047-447b-832c-82267de254b3	realm_access.roles	claim.name
d71118a9-3047-447b-832c-82267de254b3	String	jsonType.label
53adcf69-158e-40c0-aa25-25a97f118f28	true	introspection.token.claim
53adcf69-158e-40c0-aa25-25a97f118f28	true	access.token.claim
277272f6-0838-44b5-8550-7e16e31bac81	true	introspection.token.claim
277272f6-0838-44b5-8550-7e16e31bac81	true	userinfo.token.claim
277272f6-0838-44b5-8550-7e16e31bac81	username	user.attribute
277272f6-0838-44b5-8550-7e16e31bac81	true	id.token.claim
277272f6-0838-44b5-8550-7e16e31bac81	true	access.token.claim
277272f6-0838-44b5-8550-7e16e31bac81	upn	claim.name
277272f6-0838-44b5-8550-7e16e31bac81	String	jsonType.label
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	true	introspection.token.claim
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	true	multivalued
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	foo	user.attribute
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	true	id.token.claim
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	true	access.token.claim
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	groups	claim.name
f412eb8e-b75c-4cc4-bafb-4b1e0cbe758b	String	jsonType.label
eb60ea27-47c2-4e95-910b-364f325a6a28	true	introspection.token.claim
eb60ea27-47c2-4e95-910b-364f325a6a28	true	id.token.claim
eb60ea27-47c2-4e95-910b-364f325a6a28	true	access.token.claim
08af6453-44eb-4d17-8cb0-5c4ac7b2dbb1	true	introspection.token.claim
08af6453-44eb-4d17-8cb0-5c4ac7b2dbb1	true	access.token.claim
3b53c3ec-58a6-426e-89af-a9a2a1f76955	AUTH_TIME	user.session.note
3b53c3ec-58a6-426e-89af-a9a2a1f76955	true	introspection.token.claim
3b53c3ec-58a6-426e-89af-a9a2a1f76955	true	id.token.claim
3b53c3ec-58a6-426e-89af-a9a2a1f76955	true	access.token.claim
3b53c3ec-58a6-426e-89af-a9a2a1f76955	auth_time	claim.name
3b53c3ec-58a6-426e-89af-a9a2a1f76955	long	jsonType.label
36002dd9-859f-450a-843a-c4ba7f836bd5	clientHost	user.session.note
36002dd9-859f-450a-843a-c4ba7f836bd5	true	introspection.token.claim
36002dd9-859f-450a-843a-c4ba7f836bd5	true	id.token.claim
36002dd9-859f-450a-843a-c4ba7f836bd5	true	access.token.claim
36002dd9-859f-450a-843a-c4ba7f836bd5	clientHost	claim.name
36002dd9-859f-450a-843a-c4ba7f836bd5	String	jsonType.label
5b3a351f-75b6-44f6-870d-8d41e145a4a6	clientAddress	user.session.note
5b3a351f-75b6-44f6-870d-8d41e145a4a6	true	introspection.token.claim
5b3a351f-75b6-44f6-870d-8d41e145a4a6	true	id.token.claim
5b3a351f-75b6-44f6-870d-8d41e145a4a6	true	access.token.claim
5b3a351f-75b6-44f6-870d-8d41e145a4a6	clientAddress	claim.name
5b3a351f-75b6-44f6-870d-8d41e145a4a6	String	jsonType.label
d473c81b-182c-4f65-b7a6-4fa755a68c4c	client_id	user.session.note
d473c81b-182c-4f65-b7a6-4fa755a68c4c	true	introspection.token.claim
d473c81b-182c-4f65-b7a6-4fa755a68c4c	true	id.token.claim
d473c81b-182c-4f65-b7a6-4fa755a68c4c	true	access.token.claim
d473c81b-182c-4f65-b7a6-4fa755a68c4c	client_id	claim.name
d473c81b-182c-4f65-b7a6-4fa755a68c4c	String	jsonType.label
13cd259b-ca58-400d-a9c6-d89728cdc39d	true	introspection.token.claim
13cd259b-ca58-400d-a9c6-d89728cdc39d	true	multivalued
13cd259b-ca58-400d-a9c6-d89728cdc39d	true	id.token.claim
13cd259b-ca58-400d-a9c6-d89728cdc39d	true	access.token.claim
13cd259b-ca58-400d-a9c6-d89728cdc39d	organization	claim.name
13cd259b-ca58-400d-a9c6-d89728cdc39d	String	jsonType.label
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	parkigo	clientId
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	true	userinfo.token.claim
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	true	multivalued
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	true	id.token.claim
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	true	access.token.claim
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	roles	claim.name
5ce6b663-8edb-4f23-93ab-9fd2d32f47b9	String	jsonType.label
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	true	introspection.token.claim
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	true	userinfo.token.claim
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	locale	user.attribute
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	true	id.token.claim
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	true	access.token.claim
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	locale	claim.name
8613a9b5-ae08-4d7c-8f1d-b874396ddb2d	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	7ec446a5-c642-4994-b419-0806329b58bf	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	4825d051-4802-4fda-84ec-6331b657cc4a	52cf7491-c40e-4e24-b418-f1a628589451	0c617b1a-9155-4003-a07a-014bbf07ed8b	3388ba99-da5a-4959-b4b5-9c7a3da98ffd	f6fc3b14-b7c4-4384-91bf-2eeaede7b390	2592000	f	900	t	f	dd3a2e04-08e0-47a2-86c3-e36656a7550e	0	f	0	0	6dd805e3-8294-4275-8426-5a6940872806
b8bb26cb-496e-4ae0-94bc-8c9268be7494	60	300	300	\N	\N	\N	t	f	0	\N	nextjs-dashboard	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	71e6ce67-d333-4504-95f7-b5a95a6ed3c3	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	4c76e54e-be78-4feb-ad59-d346f4cfbe64	ec4be730-d525-4c2b-be48-23483b54b460	91dbd84c-361e-41b2-a4c5-f092eff56c47	08e3bcf7-73bd-4eb4-82a6-ed0bba37fbc8	f4a38d03-32e0-44ba-828d-561f926dd9aa	2592000	f	900	t	f	d767940b-7f44-4bfb-848c-768a11f3cc93	0	f	0	0	21a7ccab-f27c-4bd6-8f34-2ca60d790608
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	
_browser_header.xContentTypeOptions	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	nosniff
_browser_header.referrerPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	no-referrer
_browser_header.xRobotsTag	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	none
_browser_header.xFrameOptions	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	SAMEORIGIN
_browser_header.contentSecurityPolicy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.strictTransportSecurity	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	max-age=31536000; includeSubDomains
bruteForceProtected	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	false
permanentLockout	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	false
maxTemporaryLockouts	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	0
bruteForceStrategy	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	MULTIPLE
maxFailureWaitSeconds	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	900
minimumQuickLoginWaitSeconds	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	60
waitIncrementSeconds	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	60
quickLoginCheckMilliSeconds	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	1000
maxDeltaTimeSeconds	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	43200
failureFactor	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	30
realmReusableOtpCode	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	false
firstBrokerLoginFlowId	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	aa29d358-ba88-4eed-bb4f-c2526d4b4fcb
displayName	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	Keycloak
displayNameHtml	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	RS256
offlineSessionMaxLifespanEnabled	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	false
offlineSessionMaxLifespan	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	5184000
_browser_header.contentSecurityPolicyReportOnly	b8bb26cb-496e-4ae0-94bc-8c9268be7494	
_browser_header.xContentTypeOptions	b8bb26cb-496e-4ae0-94bc-8c9268be7494	nosniff
_browser_header.referrerPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	no-referrer
_browser_header.xRobotsTag	b8bb26cb-496e-4ae0-94bc-8c9268be7494	none
_browser_header.xFrameOptions	b8bb26cb-496e-4ae0-94bc-8c9268be7494	SAMEORIGIN
_browser_header.contentSecurityPolicy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.strictTransportSecurity	b8bb26cb-496e-4ae0-94bc-8c9268be7494	max-age=31536000; includeSubDomains
bruteForceProtected	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
permanentLockout	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
maxTemporaryLockouts	b8bb26cb-496e-4ae0-94bc-8c9268be7494	0
bruteForceStrategy	b8bb26cb-496e-4ae0-94bc-8c9268be7494	MULTIPLE
maxFailureWaitSeconds	b8bb26cb-496e-4ae0-94bc-8c9268be7494	900
minimumQuickLoginWaitSeconds	b8bb26cb-496e-4ae0-94bc-8c9268be7494	60
waitIncrementSeconds	b8bb26cb-496e-4ae0-94bc-8c9268be7494	60
quickLoginCheckMilliSeconds	b8bb26cb-496e-4ae0-94bc-8c9268be7494	1000
maxDeltaTimeSeconds	b8bb26cb-496e-4ae0-94bc-8c9268be7494	43200
failureFactor	b8bb26cb-496e-4ae0-94bc-8c9268be7494	30
realmReusableOtpCode	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
defaultSignatureAlgorithm	b8bb26cb-496e-4ae0-94bc-8c9268be7494	RS256
offlineSessionMaxLifespanEnabled	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
offlineSessionMaxLifespan	b8bb26cb-496e-4ae0-94bc-8c9268be7494	5184000
actionTokenGeneratedByAdminLifespan	b8bb26cb-496e-4ae0-94bc-8c9268be7494	43200
actionTokenGeneratedByUserLifespan	b8bb26cb-496e-4ae0-94bc-8c9268be7494	300
oauth2DeviceCodeLifespan	b8bb26cb-496e-4ae0-94bc-8c9268be7494	600
oauth2DevicePollingInterval	b8bb26cb-496e-4ae0-94bc-8c9268be7494	5
webAuthnPolicyRpEntityName	b8bb26cb-496e-4ae0-94bc-8c9268be7494	keycloak
webAuthnPolicySignatureAlgorithms	b8bb26cb-496e-4ae0-94bc-8c9268be7494	ES256,RS256
webAuthnPolicyRpId	b8bb26cb-496e-4ae0-94bc-8c9268be7494	
webAuthnPolicyAttestationConveyancePreference	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyAuthenticatorAttachment	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyRequireResidentKey	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyUserVerificationRequirement	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyCreateTimeout	b8bb26cb-496e-4ae0-94bc-8c9268be7494	0
webAuthnPolicyAvoidSameAuthenticatorRegister	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
webAuthnPolicyRpEntityNamePasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	ES256,RS256
webAuthnPolicyRpIdPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	
webAuthnPolicyAttestationConveyancePreferencePasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyRequireResidentKeyPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	not specified
webAuthnPolicyCreateTimeoutPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	false
cibaBackchannelTokenDeliveryMode	b8bb26cb-496e-4ae0-94bc-8c9268be7494	poll
cibaExpiresIn	b8bb26cb-496e-4ae0-94bc-8c9268be7494	120
cibaInterval	b8bb26cb-496e-4ae0-94bc-8c9268be7494	5
cibaAuthRequestedUserHint	b8bb26cb-496e-4ae0-94bc-8c9268be7494	login_hint
parRequestUriLifespan	b8bb26cb-496e-4ae0-94bc-8c9268be7494	60
firstBrokerLoginFlowId	b8bb26cb-496e-4ae0-94bc-8c9268be7494	4edff1f2-2f5c-4a25-8ca5-fa43f072f9a2
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	jboss-logging
b8bb26cb-496e-4ae0-94bc-8c9268be7494	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20
password	password	t	t	b8bb26cb-496e-4ae0-94bc-8c9268be7494
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.redirect_uris (client_id, value) FROM stdin;
41589de5-a9a8-4b43-b9b8-5aee3d9ac351	/realms/master/account/*
0f762526-c25a-452c-92f9-6c00cbc28295	/realms/master/account/*
70e2e715-8e79-4b85-979a-9b96a357ddb9	/admin/master/console/*
93f2c134-c670-4909-985e-fe010ba0387f	/realms/nextjs-dashboard/account/*
da945e89-e174-4986-8638-ede57a2b5c50	/realms/nextjs-dashboard/account/*
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	/admin/nextjs-dashboard/console/*
b658886f-d909-4c90-b9d9-567d24212b2c	http://localhost:3000/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
72b53149-9b1e-40f7-a1de-0145e81b5247	VERIFY_EMAIL	Verify Email	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	VERIFY_EMAIL	50
15e53bef-94df-4865-b0e8-ca44e6b06d23	UPDATE_PROFILE	Update Profile	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	UPDATE_PROFILE	40
24c3fae5-aa5b-447b-8eed-0dc81a37f013	CONFIGURE_TOTP	Configure OTP	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	CONFIGURE_TOTP	10
bf11e356-9058-4438-be66-09beac66ccf7	UPDATE_PASSWORD	Update Password	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	UPDATE_PASSWORD	30
1235df77-56c5-4e0e-98e9-a0fffd895d06	TERMS_AND_CONDITIONS	Terms and Conditions	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	f	TERMS_AND_CONDITIONS	20
ebb8fe47-2f65-4ed9-ac78-0940247c7ffb	delete_account	Delete Account	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	f	f	delete_account	60
e5a4b27c-90aa-4631-b4f1-5f9b9eed30fc	delete_credential	Delete Credential	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	delete_credential	100
70af1397-ce2d-408d-9752-f08d6691618d	update_user_locale	Update User Locale	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	update_user_locale	1000
43e4c8ea-beba-4ff8-9c20-7d5d90eaf69a	webauthn-register	Webauthn Register	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	webauthn-register	70
09a6a21d-9c94-40c4-b87a-8473e2a2e26a	webauthn-register-passwordless	Webauthn Register Passwordless	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	webauthn-register-passwordless	80
90bfa955-d523-4d11-9810-44f6cb2affc0	VERIFY_PROFILE	Verify Profile	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	t	f	VERIFY_PROFILE	90
a3277092-b4d9-4789-b5a9-c0632d9e7824	VERIFY_EMAIL	Verify Email	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	VERIFY_EMAIL	50
9acf4621-ecf2-4e23-92fd-f805339287b9	UPDATE_PROFILE	Update Profile	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	UPDATE_PROFILE	40
9d9bd807-4b15-4d1d-90cd-2bb9799d6b25	CONFIGURE_TOTP	Configure OTP	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	CONFIGURE_TOTP	10
0152d281-67e4-4dba-a690-12617cd128a7	UPDATE_PASSWORD	Update Password	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	UPDATE_PASSWORD	30
d845f5ac-af22-4147-b919-b51aafb19918	TERMS_AND_CONDITIONS	Terms and Conditions	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f	f	TERMS_AND_CONDITIONS	20
489e232f-5819-4e94-b851-fbc97baa7930	delete_account	Delete Account	b8bb26cb-496e-4ae0-94bc-8c9268be7494	f	f	delete_account	60
5609529c-7c66-43ee-8579-3bb648275de6	delete_credential	Delete Credential	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	delete_credential	100
a39a5e91-c497-49ab-bd26-5666b3cd13d6	update_user_locale	Update User Locale	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	update_user_locale	1000
395241d5-4466-4a18-a1e0-257e71ea9388	webauthn-register	Webauthn Register	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	webauthn-register	70
2575bd0e-3d64-49f4-b879-d8bb5bfc501a	webauthn-register-passwordless	Webauthn Register Passwordless	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	webauthn-register-passwordless	80
83841030-3a2d-4ca5-9d01-4ed25f8686dd	VERIFY_PROFILE	Verify Profile	b8bb26cb-496e-4ae0-94bc-8c9268be7494	t	f	VERIFY_PROFILE	90
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: revoked_token; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.revoked_token (id, expire) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
0f762526-c25a-452c-92f9-6c00cbc28295	8c9da990-75a7-4fc1-9297-0c9ca92ff2c0
0f762526-c25a-452c-92f9-6c00cbc28295	f5d891bc-48f4-4df8-868f-31683a4b4630
da945e89-e174-4986-8638-ede57a2b5c50	38b69e99-f3e9-4ff5-8c55-4391a8ffeb04
da945e89-e174-4986-8638-ede57a2b5c50	c7f4f2ad-cc30-4b4f-9244-e08a3bb980b1
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: server_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.server_config (server_config_key, value, version) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
is_temporary_admin	true	c8aa4eda-47e0-47eb-858a-05ca984b208c	576e0e11-fc60-41cd-99f1-7b5e4df37f2e	\N	\N	\N
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
e4d137a8-ca21-4bd5-80dc-69cee3432bdb	admin@parkigo.be	admin@parkigo.be	t	t	\N	Admin	ParkiGo	b8bb26cb-496e-4ae0-94bc-8c9268be7494	admin	\N	\N	0
ecacf8de-e81a-4ca7-83d6-d7fc200bf9a4	owner@parkigo.be	owner@parkigo.be	t	t	\N	Owner	ParkiGo	b8bb26cb-496e-4ae0-94bc-8c9268be7494	owner	\N	\N	0
15d36145-5cea-49e5-9f9f-fe71bfe502fb	renter@parkigo.be	renter@parkigo.be	t	t	\N	Renter	ParkiGo	b8bb26cb-496e-4ae0-94bc-8c9268be7494	renter	\N	\N	0
c8aa4eda-47e0-47eb-858a-05ca984b208c	\N	3c8bb5ab-ef82-4aac-9d8e-9154bd67499b	f	t	\N	\N	\N	9dbad98c-d710-48d9-8c6c-8e3c6fed2d20	admin	1751384474666	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_group_membership (group_id, user_id, membership_type) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
67a08dd2-d51c-47e9-98eb-decdfc90c8f2	e4d137a8-ca21-4bd5-80dc-69cee3432bdb
d670c10d-b421-4e98-aa48-04dd9030522e	ecacf8de-e81a-4ca7-83d6-d7fc200bf9a4
4a4dd9e6-31da-4392-a818-18308f685e32	15d36145-5cea-49e5-9f9f-fe71bfe502fb
6dd805e3-8294-4275-8426-5a6940872806	c8aa4eda-47e0-47eb-858a-05ca984b208c
273b3cd6-9e43-4dd7-be4c-37b7e73f817e	c8aa4eda-47e0-47eb-858a-05ca984b208c
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.web_origins (client_id, value) FROM stdin;
70e2e715-8e79-4b85-979a-9b96a357ddb9	+
d9cf8d0c-778d-4e7a-8d9b-9fa4d7fe7203	+
b658886f-d909-4c90-b9d9-567d24212b2c	http://localhost:3000
\.


--
-- Name: org_domain ORG_DOMAIN_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.org_domain
    ADD CONSTRAINT "ORG_DOMAIN_pkey" PRIMARY KEY (id, name);


--
-- Name: org ORG_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT "ORG_pkey" PRIMARY KEY (id);


--
-- Name: server_config SERVER_CONFIG_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.server_config
    ADD CONSTRAINT "SERVER_CONFIG_pkey" PRIMARY KEY (server_config_key);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: jgroups_ping constraint_jgroups_ping; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.jgroups_ping
    ADD CONSTRAINT constraint_jgroups_ping PRIMARY KEY (address);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: revoked_token constraint_rt; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.revoked_token
    ADD CONSTRAINT constraint_rt PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: user_consent uk_external_consent; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_external_consent UNIQUE (client_storage_provider, external_client_id, user_id);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_local_consent; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_local_consent UNIQUE (client_id, user_id);


--
-- Name: org uk_org_alias; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_alias UNIQUE (realm_id, alias);


--
-- Name: org uk_org_group; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_group UNIQUE (group_id);


--
-- Name: org uk_org_name; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_name UNIQUE (realm_id, name);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_idp_for_login; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_idp_for_login ON public.identity_provider USING btree (realm_id, enabled, link_only, hide_on_login, organization_id);


--
-- Name: idx_idp_realm_org; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_idp_realm_org ON public.identity_provider USING btree (realm_id, organization_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_uss_by_broker_session_id; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_offline_uss_by_broker_session_id ON public.offline_user_session USING btree (broker_session_id, realm_id);


--
-- Name: idx_offline_uss_by_last_session_refresh; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_offline_uss_by_last_session_refresh ON public.offline_user_session USING btree (realm_id, offline_flag, last_session_refresh);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_org_domain_org_id; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_org_domain_org_id ON public.org_domain USING btree (org_id);


--
-- Name: idx_perm_ticket_owner; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_perm_ticket_owner ON public.resource_server_perm_ticket USING btree (owner);


--
-- Name: idx_perm_ticket_requester; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_perm_ticket_requester ON public.resource_server_perm_ticket USING btree (requester);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_rev_token_on_expire; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_rev_token_on_expire ON public.revoked_token USING btree (expire);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_usconsent_scope_id; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_usconsent_scope_id ON public.user_consent_client_scope USING btree (scope_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

--
-- Database "openfga" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: openfga; Type: DATABASE; Schema: -; Owner: delvauxo
--

CREATE DATABASE openfga WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE openfga OWNER TO delvauxo;

\connect openfga

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assertion; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.assertion (
    store text NOT NULL,
    authorization_model_id text NOT NULL,
    assertions bytea
);


ALTER TABLE public.assertion OWNER TO delvauxo;

--
-- Name: authorization_model; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.authorization_model (
    store text NOT NULL,
    authorization_model_id text NOT NULL,
    type text NOT NULL,
    type_definition bytea,
    schema_version text DEFAULT '1.0'::text NOT NULL,
    serialized_protobuf bytea
);


ALTER TABLE public.authorization_model OWNER TO delvauxo;

--
-- Name: changelog; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.changelog (
    store text NOT NULL,
    object_type text NOT NULL,
    object_id text NOT NULL,
    relation text NOT NULL,
    _user text NOT NULL,
    operation integer NOT NULL,
    ulid text NOT NULL,
    inserted_at timestamp with time zone NOT NULL,
    condition_name text,
    condition_context bytea
);


ALTER TABLE public.changelog OWNER TO delvauxo;

--
-- Name: goose_db_version; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.goose_db_version (
    id integer NOT NULL,
    version_id bigint NOT NULL,
    is_applied boolean NOT NULL,
    tstamp timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.goose_db_version OWNER TO delvauxo;

--
-- Name: goose_db_version_id_seq; Type: SEQUENCE; Schema: public; Owner: delvauxo
--

ALTER TABLE public.goose_db_version ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.goose_db_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: store; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.store (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.store OWNER TO delvauxo;

--
-- Name: tuple; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.tuple (
    store text NOT NULL,
    object_type text NOT NULL,
    object_id text NOT NULL,
    relation text NOT NULL,
    _user text NOT NULL,
    user_type text NOT NULL,
    ulid text NOT NULL,
    inserted_at timestamp with time zone NOT NULL,
    condition_name text,
    condition_context bytea
);


ALTER TABLE public.tuple OWNER TO delvauxo;

--
-- Data for Name: assertion; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.assertion (store, authorization_model_id, assertions) FROM stdin;
\.


--
-- Data for Name: authorization_model; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.authorization_model (store, authorization_model_id, type, type_definition, schema_version, serialized_protobuf) FROM stdin;
01JYHBHDMXPZPN1FXPK1WDG6M0	01JYHBHDR0GZ6SZPRM4CW0WS5A		\N	1.1	\\x0a1a30314a59484248445230475a36535a50524d34435730575335411203312e311a060a04757365721a8d010a0964617368626f617264120b0a0561646d696e12020a00121a0a056f776e65721211220f0a020a000a091207120561646d696e121b0a0672656e7465721211220f0a020a000a091207120561646d696e1a3a0a120a0672656e74657212080a060a04757365720a110a0561646d696e12080a060a04757365720a110a056f776e657212080a060a0475736572
\.


--
-- Data for Name: changelog; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.changelog (store, object_type, object_id, relation, _user, operation, ulid, inserted_at, condition_name, condition_context) FROM stdin;
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	admin	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	0	01JZ34TB4VS8RJ7G6HEH7NCKBM	2025-07-01 14:03:55.931766+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	owner	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	0	01JZ34V66RXZK5FNNZYPEK9Q49	2025-07-01 14:04:23.640902+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	renter	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	0	01JZ34VMH0SV07HFT4Z0JRTWYY	2025-07-01 14:04:38.304671+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	renter	renter	user:15d36145-5cea-49e5-9f9f-fe71bfe502fb	0	01JZ34W20GM7XJ74H8CJNENB1J	2025-07-01 14:04:52.113298+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	owner	owner	user:ecacf8de-e81a-4ca7-83d6-d7fc200bf9a4	0	01JZ34WJ6K9EA6BY38PNJJ36R6	2025-07-01 14:05:08.692078+00		\N
\.


--
-- Data for Name: goose_db_version; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.goose_db_version (id, version_id, is_applied, tstamp) FROM stdin;
1	0	t	2025-07-01 14:02:22.539969
2	1	t	2025-07-01 14:02:22.564803
3	2	t	2025-07-01 14:02:22.585
4	3	t	2025-07-01 14:02:22.592313
5	4	t	2025-07-01 14:02:22.602779
6	5	t	2025-07-01 14:02:22.61063
\.


--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.store (id, name, created_at, updated_at, deleted_at) FROM stdin;
01JYHBHDMXPZPN1FXPK1WDG6M0	parkigo-store	2025-06-24 16:15:03.837886+00	2025-06-24 16:15:03.837886+00	\N
\.


--
-- Data for Name: tuple; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.tuple (store, object_type, object_id, relation, _user, user_type, ulid, inserted_at, condition_name, condition_context) FROM stdin;
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	admin	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	user	01JZ34TB4VS8RJ7G6HEH7NCKBM	2025-07-01 14:03:55.931766+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	owner	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	user	01JZ34V66RXZK5FNNZYPEK9Q49	2025-07-01 14:04:23.640902+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	renter	admin	user:e4d137a8-ca21-4bd5-80dc-69cee3432bdb	user	01JZ34VMH0SV07HFT4Z0JRTWYY	2025-07-01 14:04:38.304671+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	renter	renter	user:15d36145-5cea-49e5-9f9f-fe71bfe502fb	user	01JZ34W20GM7XJ74H8CJNENB1J	2025-07-01 14:04:52.113298+00		\N
01JYHBHDMXPZPN1FXPK1WDG6M0	dashboard	owner	owner	user:ecacf8de-e81a-4ca7-83d6-d7fc200bf9a4	user	01JZ34WJ6K9EA6BY38PNJJ36R6	2025-07-01 14:05:08.692078+00		\N
\.


--
-- Name: goose_db_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: delvauxo
--

SELECT pg_catalog.setval('public.goose_db_version_id_seq', 6, true);


--
-- Name: assertion assertion_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.assertion
    ADD CONSTRAINT assertion_pkey PRIMARY KEY (store, authorization_model_id);


--
-- Name: authorization_model authorization_model_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.authorization_model
    ADD CONSTRAINT authorization_model_pkey PRIMARY KEY (store, authorization_model_id, type);


--
-- Name: changelog changelog_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.changelog
    ADD CONSTRAINT changelog_pkey PRIMARY KEY (store, ulid, object_type);


--
-- Name: goose_db_version goose_db_version_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.goose_db_version
    ADD CONSTRAINT goose_db_version_pkey PRIMARY KEY (id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: tuple tuple_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.tuple
    ADD CONSTRAINT tuple_pkey PRIMARY KEY (store, object_type, object_id, relation, _user);


--
-- Name: idx_reverse_lookup_user; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_reverse_lookup_user ON public.tuple USING btree (store, object_type, relation, _user);


--
-- Name: idx_tuple_partial_user; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_tuple_partial_user ON public.tuple USING btree (store, object_type, object_id, relation, _user) WHERE (user_type = 'user'::text);


--
-- Name: idx_tuple_partial_userset; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE INDEX idx_tuple_partial_userset ON public.tuple USING btree (store, object_type, object_id, relation, _user) WHERE (user_type = 'userset'::text);


--
-- Name: idx_tuple_ulid; Type: INDEX; Schema: public; Owner: delvauxo
--

CREATE UNIQUE INDEX idx_tuple_ulid ON public.tuple USING btree (ulid);


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "yolo" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: yolo; Type: DATABASE; Schema: -; Owner: delvauxo
--

CREATE DATABASE yolo WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE yolo OWNER TO delvauxo;

\connect yolo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.customers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    image_url character varying(255) NOT NULL
);


ALTER TABLE public.customers OWNER TO delvauxo;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.invoices (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id uuid NOT NULL,
    amount integer NOT NULL,
    status character varying(255) NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.invoices OWNER TO delvauxo;

--
-- Name: revenue; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.revenue (
    month character varying(4) NOT NULL,
    revenue integer NOT NULL
);


ALTER TABLE public.revenue OWNER TO delvauxo;

--
-- Name: users; Type: TABLE; Schema: public; Owner: delvauxo
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    email text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public.users OWNER TO delvauxo;

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.customers (id, name, email, image_url) FROM stdin;
d6e15727-9fe1-4961-8c5b-ea44a9bd81aa	Evil Rabbit	evil@rabbit.com	/customers/evil-rabbit.png
3958dc9e-712f-4377-85e9-fec4b6a6442a	Delba de Oliveira	delba@oliveira.com	/customers/delba-de-oliveira.png
3958dc9e-742f-4377-85e9-fec4b6a6442a	Lee Robinson	lee@robinson.com	/customers/lee-robinson.png
76d65c26-f784-44a2-ac19-586678f7c2f2	Michael Novotny	michael@novotny.com	/customers/michael-novotny.png
cc27c14a-0acf-4f4a-a6c9-d45682c144b9	Amy Burns	amy@burns.com	/customers/amy-burns.png
13d07535-c59e-4157-a011-f8d2ef4e0cbb	Balazs Orban	balazs@orban.com	/customers/balazs-orban.png
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.invoices (id, customer_id, amount, status, date) FROM stdin;
4d8da947-6afe-4c81-88c0-dd501a6ebd75	d6e15727-9fe1-4961-8c5b-ea44a9bd81aa	15795	pending	2022-12-06
f126ae61-284c-43f7-88d1-797f1303b4ae	3958dc9e-712f-4377-85e9-fec4b6a6442a	20348	pending	2022-11-14
25253163-2ee6-4377-b818-3b29ce5ae202	cc27c14a-0acf-4f4a-a6c9-d45682c144b9	3040	paid	2022-10-29
853e61e5-2591-43a7-81e6-2ebb914fb929	76d65c26-f784-44a2-ac19-586678f7c2f2	44800	paid	2023-09-10
29ff8f86-8bba-460c-b9ac-c8a17142384a	13d07535-c59e-4157-a011-f8d2ef4e0cbb	34577	pending	2023-08-05
fa2b5fd6-a3c3-4805-af55-a063c4f8f81e	3958dc9e-742f-4377-85e9-fec4b6a6442a	54246	pending	2023-07-16
fe7f531e-bd3e-4b46-819e-cee0717a3bba	d6e15727-9fe1-4961-8c5b-ea44a9bd81aa	666	pending	2023-06-27
0fb3a7b9-cf81-4613-b23f-848720eb7ba1	76d65c26-f784-44a2-ac19-586678f7c2f2	32545	paid	2023-06-09
1fd9575b-2f1e-499e-8444-c6e56da2704c	cc27c14a-0acf-4f4a-a6c9-d45682c144b9	1250	paid	2023-06-17
32e40232-72e7-4ad1-96ef-b579b8707f89	13d07535-c59e-4157-a011-f8d2ef4e0cbb	8546	paid	2023-06-07
fb0d9068-7b68-466c-8cd9-002e68909158	3958dc9e-712f-4377-85e9-fec4b6a6442a	500	paid	2023-08-19
096ba2ea-1fc4-4e6f-89b2-dab5af95cc1e	13d07535-c59e-4157-a011-f8d2ef4e0cbb	8945	paid	2023-06-03
606e8813-2135-4f05-b1f9-0c2a05dccd91	3958dc9e-742f-4377-85e9-fec4b6a6442a	1000	paid	2022-06-05
\.


--
-- Data for Name: revenue; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.revenue (month, revenue) FROM stdin;
Jan	2000
Feb	1800
Mar	2200
Apr	2500
May	2300
Jun	3200
Jul	3500
Aug	3700
Sep	2500
Oct	2800
Nov	3000
Dec	4800
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: delvauxo
--

COPY public.users (id, name, email, password) FROM stdin;
410544b2-4001-4271-9855-fec4b6a6442a	User	user@nextmail.com	123456
\.


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: revenue revenue_month_key; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.revenue
    ADD CONSTRAINT revenue_month_key UNIQUE (month);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: delvauxo
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

